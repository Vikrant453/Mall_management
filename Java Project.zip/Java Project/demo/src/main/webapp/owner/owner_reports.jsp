<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html>
<head>
    <title>Owner Reports | Crystal Plaza</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
        :root { --primary: #2563eb; --primary-hover: #1d4ed8; --bg-main: #f0f9ff; --card-bg: #ffffff; --text-dark: #0f172a; --text-muted: #475569; --border-color: #e2e8f0; --success: #10b981; }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Inter', sans-serif; }
        body { background-color: var(--bg-main); color: var(--text-dark); line-height: 1.6; }
        .top-nav { background: var(--card-bg); padding: 0 3rem; display: flex; justify-content: space-between; align-items: center; height: 80px; border-bottom: 1px solid var(--border-color); position: sticky; top: 0; z-index: 100; }
        .nav-brand { display: flex; align-items: center; gap: 12px; font-size: 1.5rem; font-weight: 800; }
        .brand-icon { background: var(--primary); color: white; width: 36px; height: 36px; display: flex; align-items: center; justify-content: center; border-radius: 8px; }
        .nav-tabs { display: flex; gap: 2rem; height: 100%; align-items: center; }
        .nav-tab { color: var(--text-muted); font-weight: 600; transition: 0.2s; height: 100%; display: flex; align-items: center; border-bottom: 3px solid transparent; text-decoration: none; }
        .nav-tab.active, .nav-tab:hover { color: var(--text-dark); border-bottom-color: var(--primary); }
        .container { max-width: 1000px; margin: 3rem auto; padding: 0 1.5rem; }
        .btn-primary { background: var(--primary); color: white; padding: 0.75rem 1.25rem; border: none; border-radius: 10px; font-weight: 800; cursor: pointer; text-decoration: none; display: inline-flex; gap: 10px; align-items: center; }
        .btn-primary:hover { background: var(--primary-hover); }
        .card { background: var(--card-bg); padding: 2.5rem; border-radius: 16px; border: 1px solid var(--border-color); box-shadow: 0 4px 6px rgba(0,0,0,0.05); margin-bottom: 2rem; }
        .stat-card { background: var(--card-bg); padding: 2rem; border-radius: 16px; border: 1px solid var(--border-color); text-align: center; margin-bottom: 2rem; }
        .stat-value { font-size: 3rem; font-weight: 800; color: var(--success); }
        .stat-label { color: var(--text-muted); font-weight: 600; text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 0.5rem; }
        h2 { font-weight: 800; margin-bottom: 1.5rem; }
        table { width: 100%; border-collapse: collapse; margin-top: 1rem; }
        th, td { padding: 1rem; text-align: left; border-bottom: 1px solid var(--border-color); }
        th { font-weight: 700; color: var(--text-muted); text-transform: uppercase; font-size: 0.85rem; }
        .badge { background: #d1fae5; color: #065f46; padding: 0.25rem 0.75rem; border-radius: 999px; font-size: 0.85rem; font-weight: 600; }
    </style>
</head>
<body>
    <nav class="top-nav">
        <div class="nav-tabs">
            <a href="${pageContext.request.contextPath}/owner/dashboard" class="nav-tab">Overview</a>
            <a href="${pageContext.request.contextPath}/owner/inventory" class="nav-tab">Inventory</a>
            <a href="${pageContext.request.contextPath}/owner/staff" class="nav-tab">Employees</a>
            <a href="${pageContext.request.contextPath}/owner/bills" class="nav-tab">Generate Bill</a>
            <a href="${pageContext.request.contextPath}/owner/reports" class="nav-tab active">Reports</a>
            <a href="${pageContext.request.contextPath}/owner/notifications" class="nav-tab">Notifications</a>
        </div>
        <div style="display:flex; align-items:center; gap:1.5rem;">
            <div class="nav-brand">
                <div class="brand-icon">CP</div>
                Crystal Plaza
            </div>
            <a href="${pageContext.request.contextPath}/logout" class="nav-tab" style="color: #ef4444;" title="Logout">
                <i class="fa-solid fa-right-from-bracket"></i>
            </a>
        </div>
    </nav>
    <div class="container">
        <c:choose>
            <c:when test="${not empty myShop}">
                <div class="card">
                    <div style="display:flex; justify-content:space-between; align-items:center; gap:1rem; flex-wrap:wrap;">
                        <h2 style="margin-bottom:0;"><i class="fa-solid fa-chart-bar" style="color:var(--primary)"></i> Financial Overview</h2>
                        <a class="btn-primary" href="${pageContext.request.contextPath}/owner/reports/pdf"><i class="fa-solid fa-file-pdf"></i> Export PDF</a>
                    </div>
                    
                    <div class="dashboard-grid">
                        <div class="card" style="text-align:center; padding: 1.5rem; margin-bottom: 0;">
                            <div style="font-size: 1.2rem; color: var(--text-muted); margin-bottom: 0.5rem;">Total Sales</div>
                            <div style="font-size: 2.5rem; font-weight: 800; color: #10b981;">₹${shopRevenue}</div>
                        </div>
                        <div class="card" style="text-align:center; padding: 1.5rem; margin-bottom: 0;">
                            <div style="font-size: 1.2rem; color: var(--text-muted); margin-bottom: 0.5rem;">Transactions</div>
                            <div style="font-size: 2.5rem; font-weight: 800; color: #3b82f6;">${bills.size()}</div>
                        </div>
                    </div>
                    
                    <div style="margin-top: 2rem;">
                        <canvas id="revenueChart" height="100"></canvas>
                    </div>
                </div>

                <div class="card">
                    <h2><i class="fa-solid fa-list" style="color:var(--primary)"></i> Transaction History</h2>
                    <div style="overflow-x:auto;">
                        <table>
                            <thead>
                                <tr>
                                    <th>Bill ID</th>
                                    <th>Date</th>
                                    <th>Customer</th>
                                    <th>Phone</th>
                                    <th>Amount</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <c:forEach var="bill" items="${bills}">
                                    <tr>
                                        <td>#${bill.id}</td>
                                        <td>${bill.billDate}</td>
                                        <td>${bill.customerName}</td>
                                        <td>${bill.customerPhone}</td>
                                        <td><strong>₹${bill.totalAmount}</strong></td>
                                        <td><span class="badge">${bill.status}</span></td>
                                    </tr>
                                </c:forEach>
                                <c:if test="${empty bills}">
                                    <tr><td colspan="6" style="text-align:center; color:var(--text-muted); padding:2rem;">No bills generated yet.</td></tr>
                                </c:if>
                            </tbody>
                        </table>
                    </div>
                </div>
            </c:when>
            <c:otherwise>
                <div class="card" style="text-align:center; color:var(--text-muted);">
                    <h2>No Shop Assigned</h2>
                    <p>You need to be assigned to a shop by an administrator.</p>
                </div>
            </c:otherwise>
        </c:choose>
    </div>

    <!-- Announcement Toast -->
    <div id="toastContainer" style="position: fixed; bottom: 20px; right: 20px; z-index: 9999;"></div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sockjs-client/1.5.1/sockjs.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/stomp.js/2.3.3/stomp.min.js"></script>
    <script>
        <c:if test="${not empty myShop}">
            const ctx = document.getElementById('revenueChart').getContext('2d');
            const dates = [];
            const amounts = [];
            
            <c:forEach items="${bills}" var="bill">
                dates.push('${bill.billDate}');
                amounts.push(${bill.totalAmount});
            </c:forEach>

            new Chart(ctx, {
                type: 'line',
                data: {
                    labels: dates,
                    datasets: [{
                        label: 'Bill Amount (₹)',
                        data: amounts,
                        backgroundColor: 'rgba(37, 99, 235, 0.2)',
                        borderColor: 'rgba(37, 99, 235, 1)',
                        borderWidth: 2,
                        fill: true,
                        tension: 0.3
                    }]
                },
                options: { responsive: true, plugins: { legend: { position: 'top' } } }
            });
        </c:if>

        // WebSocket setup
        var stompClient = null;
        function connect() {
            var socket = new SockJS('${pageContext.request.contextPath}/ws');
            stompClient = Stomp.over(socket);
            stompClient.connect({}, function (frame) {
                stompClient.subscribe('/topic/public', function (message) {
                    var data = JSON.parse(message.body);
                    if (data.type === 'CHAT' && data.role === 'admin') {
                        showToast(data.content);
                    }
                });
            });
        }
        function showToast(message) {
            const container = document.getElementById('toastContainer');
            const toast = document.createElement('div');
            toast.style.cssText = 'background: white; border-left: 4px solid var(--primary); padding: 15px 20px; margin-top: 10px; border-radius: 4px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); width: 300px; transform: translateX(100%); transition: 0.3s;';
            toast.innerHTML = `<h4 style="margin-bottom:5px; color:var(--text-dark);"><i class="fa-solid fa-bell" style="color:var(--primary)"></i> Admin Announcement</h4><p style="color:var(--text-muted); font-size:0.9rem;">\${message}</p>`;
            container.appendChild(toast);
            setTimeout(() => { toast.style.transform = 'translateX(0)'; }, 10);
            setTimeout(() => { toast.style.transform = 'translateX(100%)'; setTimeout(() => toast.remove(), 300); }, 6000);
        }
        connect();
    </script>
</body>
</html>
