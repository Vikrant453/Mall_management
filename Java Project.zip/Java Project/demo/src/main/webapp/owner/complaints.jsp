<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html>
<head>
    <title>Customer Complaints & Reviews | Crystal Plaza</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
        :root { --primary: #f59e0b; --primary-hover: #d97706; --bg-main: #fffbeb; --card-bg: #ffffff; --text-dark: #1e293b; --text-muted: #64748b; --border-color: #f1f5f9; --danger: #ef4444; }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Inter', sans-serif; }
        body { background-color: var(--bg-main); color: var(--text-dark); line-height: 1.6; }
        .top-nav { background: var(--card-bg); padding: 0 3rem; display: flex; justify-content: space-between; align-items: center; height: 80px; border-bottom: 1px solid var(--border-color); position: sticky; top: 0; z-index: 100; box-shadow: 0 1px 3px rgba(0,0,0,0.05); }
        .nav-tabs { display: flex; gap: 2rem; height: 100%; align-items: center; }
        .nav-tab { color: var(--text-muted); font-weight: 600; transition: 0.2s; height: 100%; display: flex; align-items: center; border-bottom: 3px solid transparent; text-decoration: none; }
        .nav-tab.active, .nav-tab:hover { color: var(--text-dark); border-bottom-color: var(--primary); }
        .nav-brand { display: flex; align-items: center; gap: 12px; font-size: 1.5rem; font-weight: 800; }
        .brand-icon { background: var(--primary); color: white; width: 36px; height: 36px; display: flex; align-items: center; justify-content: center; border-radius: 8px; }
        .container { max-width: 1000px; margin: 3rem auto; padding: 0 1.5rem; }
        .card { background: var(--card-bg); padding: 2.5rem; border-radius: 16px; border: 1px solid var(--border-color); box-shadow: 0 4px 6px rgba(0,0,0,0.05); margin-bottom: 2rem; }
        h2 { font-weight: 800; margin-bottom: 1.5rem; display: flex; align-items: center; gap: 10px; }
        
        .complaint-list { display: flex; flex-direction: column; gap: 1.5rem; }
        .complaint-item { background: #fdfaf0; border: 1px solid #fde68a; border-radius: 12px; padding: 1.5rem; }
        .complaint-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem; border-bottom: 1px solid #fef08a; padding-bottom: 0.5rem; }
        .customer-name { font-weight: 700; font-size: 1.1rem; color: #b45309; }
        .complaint-date { color: var(--text-muted); font-size: 0.85rem; }
        .complaint-content { color: var(--text-dark); font-size: 1rem; line-height: 1.5; }
    </style>
</head>
<body>
    <nav class="top-nav">
        <div class="nav-tabs">
            <a href="${pageContext.request.contextPath}/owner/dashboard" class="nav-tab">Overview</a>
            <a href="${pageContext.request.contextPath}/owner/inventory" class="nav-tab">Inventory</a>
            <a href="${pageContext.request.contextPath}/owner/bills" class="nav-tab">Generate Bill</a>
            <a href="${pageContext.request.contextPath}/owner/complaints" class="nav-tab active">Reviews</a>
            <a href="${pageContext.request.contextPath}/owner/messenger" class="nav-tab">Global Chat</a>
        </div>
        <div style="display:flex; align-items:center; gap:1.5rem;">
            <div class="nav-brand">
                <div class="brand-icon">CP</div>
                Crystal Plaza
            </div>
            <a href="${pageContext.request.contextPath}/logout" class="nav-tab" style="color: #ef4444;" title="Logout">
                <i class="fa-solid fa-right-from-bracket"></i>
            </a>
        </div>
    </nav>
    <div class="container">
        <div class="card">
            <h2><i class="fa-solid fa-comments" style="color:var(--primary)"></i> Customer Feedback & Complaints</h2>
            <c:choose>
                <c:when test="${empty myShop}">
                    <div style="text-align:center; color:var(--text-muted); padding:2rem;">
                        <p>You need to be assigned to a shop by an administrator to receive feedback.</p>
                    </div>
                </c:when>
                <c:otherwise>
                    <div class="complaint-list">
                        <c:forEach var="complaint" items="${complaints}">
                            <div class="complaint-item">
                                <div class="complaint-header">
                                    <div class="customer-name"><i class="fa-solid fa-user-circle"></i> ${complaint.customerName}</div>
                                    <div class="complaint-date"><i class="fa-regular fa-clock"></i> ${complaint.timestamp.toLocalDate()} ${complaint.timestamp.toLocalTime()}</div>
                                </div>
                                <div class="complaint-content">
                                    ${complaint.content}
                                </div>
                            </div>
                        </c:forEach>
                        <c:if test="${empty complaints}">
                            <div style="text-align:center; color:var(--text-muted); padding:3rem;">
                                <i class="fa-regular fa-face-smile" style="font-size:3rem; margin-bottom:1rem; color:#d1d5db;"></i>
                                <p>No feedback or complaints received yet.</p>
                            </div>
                        </c:if>
                    </div>
                </c:otherwise>
            </c:choose>
        </div>
    </div>
</body>
</html>
