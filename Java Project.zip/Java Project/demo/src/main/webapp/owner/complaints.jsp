<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html>
<head>
    <title>Customer Complaints & Reviews | Crystal Plaza</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
        :root { --primary: #2563eb; --primary-hover: #1d4ed8; --bg-main: #f0f9ff; --card-bg: #ffffff; --text-dark: #0f172a; --text-muted: #475569; --border-color: #e2e8f0; --danger: #ef4444; }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Inter', sans-serif; }
        body { background-color: var(--bg-main); color: var(--text-dark); line-height: 1.6; }
        .top-nav { background: var(--card-bg); padding: 0 3rem; display: flex; justify-content: space-between; align-items: center; height: 80px; border-bottom: 1px solid var(--border-color); position: sticky; top: 0; z-index: 100; box-shadow: 0 1px 3px rgba(0,0,0,0.05); }
        .nav-tabs { display: flex; gap: 2rem; height: 100%; align-items: center; }
        .nav-tab { color: var(--text-muted); font-weight: 600; transition: 0.2s; height: 100%; display: flex; align-items: center; border-bottom: 3px solid transparent; text-decoration: none; }
        .nav-tab.active, .nav-tab:hover { color: var(--text-dark); border-bottom-color: var(--primary); }
        .nav-brand { display: flex; align-items: center; gap: 12px; font-size: 1.5rem; font-weight: 800; }
        .brand-icon { background: var(--primary); color: white; width: 36px; height: 36px; display: flex; align-items: center; justify-content: center; border-radius: 8px; }
        .container { max-width: 1000px; margin: 3rem auto; padding: 0 1.5rem; }
        .card { background: var(--card-bg); padding: 2.5rem; border-radius: 16px; border: 1px solid var(--border-color); box-shadow: 0 4px 6px rgba(0,0,0,0.05); margin-bottom: 2rem; }
        h2 { font-weight: 800; margin-bottom: 1.5rem; display: flex; align-items: center; gap: 10px; }
        
        .complaint-list { display: flex; flex-direction: column; gap: 1.5rem; }
        .complaint-item { background: #ffffff; border: 1px solid var(--border-color); border-radius: 12px; padding: 1.5rem; }
        .complaint-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem; border-bottom: 1px solid var(--border-color); padding-bottom: 0.5rem; }
        .customer-name { font-weight: 700; font-size: 1.1rem; color: var(--primary); }
        .complaint-date { color: var(--text-muted); font-size: 0.85rem; }
        .complaint-content { color: var(--text-dark); font-size: 1rem; line-height: 1.5; }
        .reply-box { margin-top: 1rem; padding-top: 1rem; border-top: 1px dashed var(--border-color); }
        .reply-label { font-weight: 700; font-size: 0.9rem; color: var(--text-muted); margin-bottom: 0.5rem; }
        .reply-form textarea { width: 100%; padding: 0.75rem; border: 1px solid var(--border-color); border-radius: 10px; resize: vertical; font-family: 'Inter', sans-serif; }
        .reply-form button { margin-top: 0.75rem; background: var(--primary); color: white; border: none; border-radius: 10px; padding: 0.7rem 1rem; font-weight: 700; cursor: pointer; }
        .reply-form button:hover { background: var(--primary-hover); }
    </style>
</head>
<body>
    <nav class="top-nav">
        <div class="nav-tabs">
            <a href="${pageContext.request.contextPath}/owner/dashboard" class="nav-tab">Overview</a>
            <a href="${pageContext.request.contextPath}/owner/inventory" class="nav-tab">Inventory</a>
            <a href="${pageContext.request.contextPath}/owner/bills" class="nav-tab">Generate Bill</a>
            <a href="${pageContext.request.contextPath}/owner/complaints" class="nav-tab active">Reviews</a>
            <a href="${pageContext.request.contextPath}/owner/messenger" class="nav-tab">Global Chat</a>
        </div>
        <div style="display:flex; align-items:center; gap:1.5rem;">
            <div class="nav-brand">
                <div class="brand-icon">CP</div>
                Crystal Plaza
            </div>
            <a href="${pageContext.request.contextPath}/logout" class="nav-tab" style="color: #ef4444;" title="Logout">
                <i class="fa-solid fa-right-from-bracket"></i>
            </a>
        </div>
    </nav>
    <div class="container">
        <div class="card">
            <h2><i class="fa-solid fa-comments" style="color:var(--primary)"></i> Customer Feedback & Complaints</h2>
            <c:choose>
                <c:when test="${empty myShop}">
                    <div style="text-align:center; color:var(--text-muted); padding:2rem;">
                        <p>You need to be assigned to a shop by an administrator to receive feedback.</p>
                    </div>
                </c:when>
                <c:otherwise>
                    <div class="complaint-list">
                        <c:forEach var="complaint" items="${complaints}">
                            <div class="complaint-item">
                                <div class="complaint-header">
                                    <div class="customer-name"><i class="fa-solid fa-user-circle"></i> ${complaint.customerName}</div>
                                    <div class="complaint-date"><i class="fa-regular fa-clock"></i> ${complaint.timestamp.toLocalDate()} ${complaint.timestamp.toLocalTime()}</div>
                                </div>
                                <div class="complaint-content">
                                    ${complaint.content}
                                </div>
                                <div class="reply-box">
                                    <div class="reply-label"><i class="fa-solid fa-reply"></i> Your Reply</div>
                                    <c:if test="${not empty complaint.ownerReply}">
                                        <div style="background: #eff6ff; border: 1px solid #dbeafe; color: #1e40af; padding: 0.75rem; border-radius: 10px; font-weight: 600;">
                                            ${complaint.ownerReply}
                                        </div>
                                    </c:if>
                                    <form class="reply-form" action="${pageContext.request.contextPath}/owner/complaint/reply" method="post" style="margin-top:0.75rem;">
                                        <input type="hidden" name="complaintId" value="${complaint.id}">
                                        <textarea name="ownerReply" rows="2" placeholder="Write a reply to the customer..." required>${complaint.ownerReply}</textarea>
                                        <button type="submit"><i class="fa-solid fa-paper-plane"></i> Save Reply</button>
                                    </form>
                                </div>
                            </div>
                        </c:forEach>
                        <c:if test="${empty complaints}">
                            <div style="text-align:center; color:var(--text-muted); padding:3rem;">
                                <i class="fa-regular fa-face-smile" style="font-size:3rem; margin-bottom:1rem; color:#d1d5db;"></i>
                                <p>No feedback or complaints received yet.</p>
                            </div>
                        </c:if>
                    </div>
                </c:otherwise>
            </c:choose>
        </div>
    </div>
</body>
</html>
