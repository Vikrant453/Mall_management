<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html>
<head>
    <title>Employees | Crystal Plaza</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
        :root { --primary: #2563eb; --primary-hover: #1d4ed8; --bg-main: #f0f9ff; --card-bg: #ffffff; --text-dark: #0f172a; --text-muted: #475569; --border-color: #e2e8f0; --danger: #ef4444; }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Inter', sans-serif; }
        body { background-color: var(--bg-main); color: var(--text-dark); line-height: 1.6; }
        .top-nav { background: var(--card-bg); padding: 0 3rem; display: flex; justify-content: space-between; align-items: center; height: 80px; border-bottom: 1px solid var(--border-color); position: sticky; top: 0; z-index: 100; }
        .nav-brand { display: flex; align-items: center; gap: 12px; font-size: 1.5rem; font-weight: 800; }
        .brand-icon { background: var(--primary); color: white; width: 36px; height: 36px; display: flex; align-items: center; justify-content: center; border-radius: 8px; }
        .nav-tabs { display: flex; gap: 2rem; height: 100%; align-items: center; }
        .nav-tab { color: var(--text-muted); font-weight: 600; transition: 0.2s; height: 100%; display: flex; align-items: center; border-bottom: 3px solid transparent; text-decoration: none; }
        .nav-tab.active, .nav-tab:hover { color: var(--text-dark); border-bottom-color: var(--primary); }
        .container { max-width: 1200px; margin: 3rem auto; padding: 0 1.5rem; }
        .card { background: var(--card-bg); padding: 2rem; border-radius: 16px; border: 1px solid var(--border-color); box-shadow: 0 1px 3px rgba(0,0,0,0.05); margin-bottom: 2rem; }
        h2 { font-weight: 800; margin-bottom: 1.5rem; display: flex; align-items: center; gap: 10px; }
        .form-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1.5rem; margin-bottom: 1.5rem; }
        .form-group label { display: block; font-weight: 600; margin-bottom: 0.5rem; }
        .form-group input { width: 100%; padding: 0.75rem; border: 1px solid var(--border-color); border-radius: 8px; font-size: 1rem; }
        .btn-primary { background: var(--primary); color: white; padding: 0.75rem 1.5rem; border: none; border-radius: 8px; font-weight: 600; cursor: pointer; transition: 0.2s; }
        .btn-primary:hover { background: var(--primary-hover); }
        table { width: 100%; border-collapse: collapse; margin-top: 1rem; }
        th, td { padding: 1rem; text-align: left; border-bottom: 1px solid var(--border-color); }
        th { font-weight: 700; color: var(--text-muted); text-transform: uppercase; font-size: 0.85rem; letter-spacing: 0.05em; }
        tr:hover { background: #f8fafc; }
        .btn-danger { background: var(--danger); color: white; padding: 0.5rem 1rem; border: none; border-radius: 6px; cursor: pointer; font-weight: 600; font-size: 0.9rem; }
        .btn-danger:hover { opacity: 0.9; }
        .alert-success { background: #d1fae5; color: #065f46; padding: 1rem; border-radius: 8px; margin-bottom: 2rem; font-weight: 600; }
        .badge { background: #dbeafe; color: var(--primary); padding: 0.25rem 0.75rem; border-radius: 999px; font-size: 0.85rem; font-weight: 600; }
    </style>
</head>
<body>
    <nav class="top-nav">
        <div class="nav-tabs">
            <a href="${pageContext.request.contextPath}/owner/dashboard" class="nav-tab">Overview</a>
            <a href="${pageContext.request.contextPath}/owner/inventory" class="nav-tab">Inventory</a>
            <a href="${pageContext.request.contextPath}/owner/staff" class="nav-tab active">Employees</a>
            <a href="${pageContext.request.contextPath}/owner/bills" class="nav-tab">Generate Bill</a>
            <a href="${pageContext.request.contextPath}/owner/reports" class="nav-tab">Reports</a>
            <a href="${pageContext.request.contextPath}/owner/notifications" class="nav-tab">Notifications</a>
        </div>
        <div style="display:flex; align-items:center; gap:1.5rem;">
            <div class="nav-brand">
                <div class="brand-icon">CP</div>
                Crystal Plaza
            </div>
            <a href="${pageContext.request.contextPath}/logout" class="nav-tab" style="color: #ef4444;" title="Logout">
                <i class="fa-solid fa-right-from-bracket"></i>
            </a>
        </div>
    </nav>
    <div class="container">
        <c:if test="${not empty param.success}">
            <div class="alert-success"><i class="fa-solid fa-check-circle"></i> ${param.success}</div>
        </c:if>

        <c:choose>
            <c:when test="${not empty myShop}">
                <div class="card">
                    <h2><i class="fa-solid fa-user-plus" style="color:var(--primary)"></i> Register New Employee</h2>
                    <form action="${pageContext.request.contextPath}/owner/staff/add" method="post">
                        <input type="hidden" name="shopId" value="${myShop.id}">
                        <div class="form-grid">
                            <div class="form-group">
                                <label>Employee Name</label>
                                <input type="text" name="name" required placeholder="e.g. John Doe">
                            </div>
                            <div class="form-group">
                                <label>Designation</label>
                                <input type="text" name="designation" required placeholder="e.g. Cashier, Sales, Manager">
                            </div>
                            <div class="form-group">
                                <label>Monthly Salary (₹)</label>
                                <input type="number" step="0.01" name="salary" required placeholder="15000">
                            </div>
                        </div>
                        <button type="submit" class="btn-primary" style="margin-top: 1rem;"><i class="fa-solid fa-plus"></i> Add Employee</button>
                    </form>
                </div>

                <div class="card">
                    <h2><i class="fa-solid fa-users" style="color:var(--primary)"></i> Staff List for ${myShop.shopName}</h2>
                    <div style="overflow-x:auto;">
                        <table>
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Designation</th>
                                    <th>Salary</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <c:forEach var="emp" items="${employees}">
                                    <tr>
                                        <td>#${emp.id}</td>
                                        <td><strong>${emp.name}</strong></td>
                                        <td><span class="badge">${emp.designation}</span></td>
                                        <td>₹${emp.salary}</td>
                                        <td>
                                            <form action="${pageContext.request.contextPath}/owner/staff/delete/${emp.id}" method="post" style="display:inline;">
                                                <button type="submit" class="btn-danger" onclick="return confirm('Remove employee?');"><i class="fa-solid fa-trash"></i></button>
                                            </form>
                                        </td>
                                    </tr>
                                </c:forEach>
                                <c:if test="${empty employees}">
                                    <tr><td colspan="5" style="text-align:center; color:var(--text-muted); padding:2rem;">No employees added yet.</td></tr>
                                </c:if>
                            </tbody>
                        </table>
                    </div>
                </div>
            </c:when>
            <c:otherwise>
                <div class="card" style="text-align:center; color:var(--text-muted);">
                    <h2>No Shop Assigned</h2>
                    <p>You need to be assigned to a shop by an administrator before managing staff.</p>
                </div>
            </c:otherwise>
        </c:choose>
    </div>

    <!-- Announcement Toast -->
    <div id="toastContainer" style="position: fixed; bottom: 20px; right: 20px; z-index: 9999;"></div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/sockjs-client/1.5.1/sockjs.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/stomp.js/2.3.3/stomp.min.js"></script>
    <script>
        var stompClient = null;
        function connect() {
            var socket = new SockJS('${pageContext.request.contextPath}/ws');
            stompClient = Stomp.over(socket);
            stompClient.connect({}, function (frame) {
                stompClient.subscribe('/topic/public', function (message) {
                    var data = JSON.parse(message.body);
                    if (data.type === 'CHAT' && data.role === 'admin') {
                        showToast(data.content);
                    }
                });
            });
        }
        function showToast(message) {
            const container = document.getElementById('toastContainer');
            const toast = document.createElement('div');
            toast.style.cssText = 'background: white; border-left: 4px solid var(--primary); padding: 15px 20px; margin-top: 10px; border-radius: 4px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); width: 300px; transform: translateX(100%); transition: 0.3s;';
            toast.innerHTML = '<h4 style="margin-bottom:5px; color:var(--text-dark);"><i class="fa-solid fa-bell" style="color:var(--primary)"></i> Admin Announcement</h4><p style="color:var(--text-muted); font-size:0.9rem;">' + message + '</p>';
            container.appendChild(toast);
            setTimeout(() => { toast.style.transform = 'translateX(0)'; }, 10);
            setTimeout(() => { toast.style.transform = 'translateX(100%)'; setTimeout(() => toast.remove(), 300); }, 6000);
        }
        connect();
    </script>
</body>
</html>
