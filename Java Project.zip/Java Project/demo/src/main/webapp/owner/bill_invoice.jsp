<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html>
<head>
    <title>Invoice #${bill.id} | Crystal Plaza</title>
    <meta charset="UTF-8">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
        body { font-family: 'Inter', sans-serif; background: #f1f5f9; color: #1e293b; margin: 0; padding: 2rem; display: flex; flex-direction: column; align-items: center; }
        .invoice-box { max-width: 800px; width: 100%; background: #ffffff; padding: 40px; box-shadow: 0 4px 6px rgba(0,0,0,0.05); }
        .header { display: flex; justify-content: space-between; border-bottom: 2px solid #e2e8f0; padding-bottom: 20px; margin-bottom: 20px; }
        .brand { font-size: 2rem; font-weight: 800; color: #f59e0b; display: flex; align-items: center; gap: 10px; }
        .brand-icon { background: #f59e0b; color: white; width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; border-radius: 8px; font-size: 1.2rem; }
        .shop-details { text-align: right; color: #64748b; }
        .invoice-details { display: flex; justify-content: space-between; margin-bottom: 30px; }
        .info-block strong { color: #0f172a; display: block; margin-bottom: 5px; }
        table { width: 100%; border-collapse: collapse; margin-bottom: 30px; }
        th { background: #f8fafc; padding: 12px; text-align: left; font-weight: 700; color: #475569; border-bottom: 2px solid #e2e8f0; }
        td { padding: 12px; border-bottom: 1px solid #e2e8f0; }
        .total-row td { font-weight: 800; font-size: 1.2rem; border-top: 2px solid #cbd5e1; }
        .footer { text-align: center; color: #64748b; margin-top: 50px; font-size: 0.9rem; }
        .actions { margin-bottom: 20px; display: flex; gap: 10px; }
        .btn { padding: 10px 20px; border-radius: 8px; font-weight: 600; cursor: pointer; border: none; text-decoration: none; display: inline-flex; align-items: center; gap: 8px; transition: 0.2s; }
        .btn-primary { background: #f59e0b; color: white; }
        .btn-primary:hover { background: #d97706; }
        .btn-outline { background: white; color: #475569; border: 1px solid #cbd5e1; }
        .btn-outline:hover { background: #f1f5f9; }
    </style>
</head>
<body>
    <div class="actions">
        <button onclick="downloadPDF()" class="btn btn-primary"><i class="fa-solid fa-download"></i> Download PDF</button>
        <a href="${pageContext.request.contextPath}/owner/bills" class="btn btn-outline"><i class="fa-solid fa-arrow-left"></i> Back to Generator</a>
    </div>

    <div class="invoice-box" id="invoice">
        <div class="header">
            <div class="brand">
                <div class="brand-icon">CP</div>
                Crystal Plaza
            </div>
            <div class="shop-details">
                <strong style="font-size: 1.2rem; color: #0f172a;">${bill.shop.shopName}</strong><br>
                ${bill.shop.category} | Floor ${bill.shop.floorNumber}<br>
                Crystal Plaza, District 5, Mumbai
            </div>
        </div>

        <div class="invoice-details">
            <div class="info-block">
                <strong>Billed To:</strong>
                ${bill.customerName}<br>
                Phone: ${bill.customerPhone}
            </div>
            <div class="info-block" style="text-align: right;">
                <strong>Invoice Number:</strong> #INV-${bill.id}<br>
                <strong>Date:</strong> ${bill.billDate.toLocalDate()}
            </div>
        </div>

        <table>
            <thead>
                <tr>
                    <th>Description</th>
                    <th>Price</th>
                    <th>Qty</th>
                    <th style="text-align: right;">Subtotal</th>
                </tr>
            </thead>
            <tbody>
                <c:forEach var="item" items="${bill.items}">
                    <tr>
                        <td>${item.itemName}</td>
                        <td>₹${item.price}</td>
                        <td>${item.quantity}</td>
                        <td style="text-align: right;">₹${item.subtotal}</td>
                    </tr>
                </c:forEach>
                <tr>
                    <td colspan="3" style="text-align: right; border-top: 2px solid #cbd5e1; font-weight: 600;">Subtotal:</td>
                    <td style="text-align: right; border-top: 2px solid #cbd5e1; font-weight: 600;">₹${bill.totalAmount}</td>
                </tr>
                <c:if test="${bill.discountPercentage > 0}">
                <tr>
                    <td colspan="3" style="text-align: right; font-weight: 600; color: #10b981;">Discount (${bill.discountPercentage}%):</td>
                    <td style="text-align: right; font-weight: 600; color: #10b981;">- ₹${bill.totalAmount - bill.finalAmount}</td>
                </tr>
                </c:if>
                <tr class="total-row">
                    <td colspan="3" style="text-align: right;">Grand Total:</td>
                    <td style="text-align: right; color: #f59e0b;">₹${bill.finalAmount != null ? bill.finalAmount : bill.totalAmount}</td>
                </tr>
            </tbody>
        </table>

        <div class="footer">
            <p>Thank you for shopping at ${bill.shop.shopName}!</p>
            <p>Crystal Plaza. Neo-Genesis Galleria, 901 Sky-Line Drive, Mumbai, Maharashtra 400001, India</p>
        </div>
    </div>

    <script>
        function downloadPDF() {
            const element = document.getElementById('invoice');
            const opt = {
                margin:       0.5,
                filename:     'invoice_INV-' + ${bill.id} + '.pdf',
                image:        { type: 'jpeg', quality: 0.98 },
                html2canvas:  { scale: 2 },
                jsPDF:        { unit: 'in', format: 'letter', orientation: 'portrait' }
            };
            html2pdf().set(opt).from(element).save();
        }
        
        // Auto-download on page load
        window.onload = function() {
            setTimeout(downloadPDF, 1000);
        };
    </script>
</body>
</html>
