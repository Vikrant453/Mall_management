<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html>
<head>
    <title>Invoice #${bill.id} | Crystal Plaza</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { margin: 0; padding: 24px; background: #eef6ff; color: #0f172a; font-family: "Courier New", monospace; display: flex; flex-direction: column; align-items: center; }
        .actions { width: 460px; max-width: 100%; margin-bottom: 12px; display: flex; gap: 10px; }
        .btn { padding: 10px 14px; border-radius: 8px; text-decoration: none; border: 1px solid #cbd5e1; font-family: Arial, sans-serif; font-weight: 700; font-size: 13px; }
        .btn-primary { background: #2563eb; color: white; border-color: #2563eb; }
        .btn-outline { background: white; color: #334155; }
        .receipt { width: 460px; max-width: 100%; background: white; border: 1px solid #dbe5f0; padding: 22px 24px; line-height: 1.5; box-shadow: 0 2px 8px rgba(0,0,0,0.06); }
        .title { text-align: center; font-size: 42px; letter-spacing: 2px; font-weight: 700; margin-bottom: 4px; }
        .sub { text-align: center; font-size: 16px; letter-spacing: 1px; margin-bottom: 8px; }
        .line { border-top: 2px dashed #6b7280; margin: 8px 0 14px; }
        .row { display: flex; justify-content: space-between; font-size: 16px; margin: 2px 0; }
        .item-head, .item-row { display: grid; grid-template-columns: 1.5fr 0.6fr 0.9fr; column-gap: 10px; font-size: 16px; }
        .item-head { font-weight: 700; margin-bottom: 6px; }
        .item-row { margin-bottom: 4px; }
        .amount { text-align: right; }
        .grand { font-size: 34px; font-weight: 800; display: flex; justify-content: space-between; margin-top: 8px; }
        .thanks { text-align: center; margin-top: 16px; font-size: 18px; }
    </style>
</head>
<body>
    <div class="actions">
        <a href="${pageContext.request.contextPath}/owner/bill/invoice/${bill.id}/pdf" class="btn btn-primary"><i class="fa-solid fa-download"></i> Download PDF</a>
        <a href="${pageContext.request.contextPath}/owner/bills" class="btn btn-outline"><i class="fa-solid fa-arrow-left"></i> Back to Generator</a>
    </div>

    <div class="receipt" id="invoice">
        <div class="title">${bill.shop.shopName}</div>
        <div class="sub">TAX INVOICE / CASH MEMO</div>
        <div class="line"></div>

        <div class="row"><span>Customer:</span><span>${bill.customerName}</span></div>
        <div class="row"><span>Contact:</span><span>${bill.customerPhone}</span></div>
        <div class="row"><span>Date:</span><span>${bill.billDate.toLocalDate()}</span></div>
        <div class="line"></div>

        <div class="item-head">
            <div>ITEM</div><div>QTY</div><div class="amount">AMOUNT</div>
        </div>
        <div class="line" style="margin-top:4px;"></div>

        <c:forEach var="item" items="${bill.items}">
            <div class="item-row">
                <div>${item.itemName}</div>
                <div>${item.quantity}</div>
                <div class="amount">${item.subtotal}</div>
            </div>
        </c:forEach>

        <div class="line"></div>
        <div class="row"><span>TOTAL ITEMS:</span><span>${bill.items.size()}</span></div>
        <c:if test="${bill.discountPercentage > 0}">
            <div class="row"><span>DISCOUNT (${bill.discountPercentage}%):</span><span>- ${bill.totalAmount - bill.finalAmount}</span></div>
        </c:if>
        <div class="grand"><span>GRAND TOTAL:</span><span>Rs.${bill.finalAmount != null ? bill.finalAmount : bill.totalAmount}</span></div>
        <div class="line"></div>
        <div class="thanks">Thank You! Please Visit Again.</div>
    </div>
</body>
</html>
