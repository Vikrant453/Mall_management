<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>Manage Inventory | ParkSmart</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
        body { font-family: 'Inter', sans-serif; background-color: #f0f9ff; color: #0f172a; text-align: center; padding: 5rem; }
        .card { background: white; padding: 3rem; border-radius: 16px; box-shadow: 0 4px 6px rgba(0,0,0,0.05); display: inline-block; }
        .btn-primary { background: #2563eb; color: white; padding: 0.75rem 1.5rem; border: none; border-radius: 8px; font-weight: 600; cursor: pointer; text-decoration: none; margin-top: 2rem; display: inline-block; }
    </style>
</head>
<body>
    <div class="card">
        <i class="fa-solid fa-boxes-stacked" style="font-size: 4rem; color: #2563eb; margin-bottom: 1rem;"></i>
        <h2>Manage Inventory</h2>
        <p>This module is currently under construction.</p>
        <a href="${pageContext.request.contextPath}/owner/dashboard" class="btn-primary">Back to Dashboard</a>
    </div>
</body>
</html>
