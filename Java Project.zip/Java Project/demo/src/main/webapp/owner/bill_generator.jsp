<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html>
<head>
    <title>Generate Bill | Crystal Plaza</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
        :root { --primary: #2563eb; --primary-hover: #1d4ed8; --bg-main: #f0f9ff; --card-bg: #ffffff; --text-dark: #0f172a; --text-muted: #475569; --border-color: #e2e8f0; --success: #10b981; }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Inter', sans-serif; }
        body { background-color: var(--bg-main); color: var(--text-dark); line-height: 1.6; }
        .top-nav { background: var(--card-bg); padding: 0 3rem; display: flex; justify-content: space-between; align-items: center; height: 80px; border-bottom: 1px solid var(--border-color); position: sticky; top: 0; z-index: 100; }
        .nav-brand { display: flex; align-items: center; gap: 12px; font-size: 1.5rem; font-weight: 800; }
        .brand-icon { background: var(--primary); color: white; width: 36px; height: 36px; display: flex; align-items: center; justify-content: center; border-radius: 8px; }
        .nav-tabs { display: flex; gap: 2rem; height: 100%; align-items: center; }
        .nav-tab { color: var(--text-muted); font-weight: 600; transition: 0.2s; height: 100%; display: flex; align-items: center; border-bottom: 3px solid transparent; text-decoration: none; }
        .nav-tab.active, .nav-tab:hover { color: var(--text-dark); border-bottom-color: var(--primary); }
        .container { max-width: 1000px; margin: 3rem auto; padding: 0 1.5rem; }
        .card { background: var(--card-bg); padding: 2.5rem; border-radius: 16px; border: 1px solid var(--border-color); box-shadow: 0 4px 6px rgba(0,0,0,0.05); margin-bottom: 2rem; }
        h2 { font-weight: 800; margin-bottom: 1.5rem; }
        .form-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1.5rem; margin-bottom: 1.5rem; }
        .form-group label { display: block; font-weight: 600; margin-bottom: 0.5rem; color: var(--text-dark); }
        .form-group input { width: 100%; padding: 0.85rem; border: 1px solid #cbd5e1; border-radius: 8px; font-size: 1rem; }
        .btn-primary { background: var(--primary); color: white; padding: 0.85rem 2rem; border: none; border-radius: 8px; font-weight: 600; font-size: 1.05rem; cursor: pointer; transition: 0.2s; width: 100%; }
        .btn-primary:hover { background: var(--primary-hover); }
        .alert-success { background: #d1fae5; color: #065f46; padding: 1rem; border-radius: 8px; margin-bottom: 2rem; font-weight: 600; }
        table { width: 100%; border-collapse: collapse; margin-top: 1rem; }
        th, td { padding: 1rem; text-align: left; border-bottom: 1px solid var(--border-color); }
        th { font-weight: 700; color: var(--text-muted); text-transform: uppercase; font-size: 0.85rem; }
        .badge { background: #d1fae5; color: #065f46; padding: 0.25rem 0.75rem; border-radius: 999px; font-size: 0.85rem; font-weight: 600; }
    </style>
</head>
<body>
<nav class="top-nav">
    <div class="nav-tabs">
        <a href="${pageContext.request.contextPath}/owner/dashboard" class="nav-tab">Overview</a>
        <a href="${pageContext.request.contextPath}/owner/inventory" class="nav-tab">Inventory</a>
        <a href="${pageContext.request.contextPath}/owner/staff" class="nav-tab">Employees</a>
        <a href="${pageContext.request.contextPath}/owner/bills" class="nav-tab active">Generate Bill</a>
        <a href="${pageContext.request.contextPath}/owner/reports" class="nav-tab">Reports</a>
        <a href="${pageContext.request.contextPath}/owner/notifications" class="nav-tab">Notifications</a>
    </div>
    <div style="display:flex; align-items:center; gap:1.5rem;">
        <div class="nav-brand">
            <div class="brand-icon">CP</div>
            Crystal Plaza
        </div>
        <a href="${pageContext.request.contextPath}/logout" class="nav-tab" style="color: #ef4444;" title="Logout">
            <i class="fa-solid fa-right-from-bracket"></i>
        </a>
    </div>
</nav>
<div class="container">
    <c:if test="${not empty param.success}">
        <div class="alert-success"><i class="fa-solid fa-check-circle"></i> ${param.success}</div>
    </c:if>

    <c:choose>
        <c:when test="${not empty myShop}">
            <div class="card">
                <h2><i class="fa-solid fa-file-invoice-dollar" style="color:var(--primary)"></i> Create New Bill</h2>
                <form action="${pageContext.request.contextPath}/owner/bill/add" method="post" id="billForm">
                    <input type="hidden" name="shopId" value="${myShop.id}">
                    <div class="form-grid">
                        <div class="form-group">
                            <label>Customer Name</label>
                            <input type="text" name="customerName" required placeholder="John Doe">
                        </div>
                        <div class="form-group">
                            <label>Customer Phone</label>
                            <input type="tel" name="customerPhone" required placeholder="9876543210">
                        </div>
                    </div>

                    <h3 style="margin-top: 1.5rem; margin-bottom: 1rem;">Line Items</h3>
                    <div style="overflow-x:auto;">
                        <table id="itemsTable">
                            <thead>
                            <tr>
                                <th>Item Name</th>
                                <th>Price (₹)</th>
                                <th>Quantity</th>
                                <th>Subtotal (₹)</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody id="itemsBody">
                            <tr>
                                <td><input type="text" name="itemName[]" required placeholder="Item" style="width:100%; padding:0.5rem;"></td>
                                <td><input type="number" step="0.01" name="price[]" class="item-price" required placeholder="0.00" style="width:100px; padding:0.5rem;" oninput="calculateTotal()"></td>
                                <td><input type="number" name="quantity[]" class="item-qty" required value="1" min="1" style="width:80px; padding:0.5rem;" oninput="calculateTotal()"></td>
                                <td><input type="text" class="item-subtotal" readonly value="0.00" style="width:100px; padding:0.5rem; background:#f1f5f9; border:none;"></td>
                                <td><button type="button" class="btn-danger" onclick="removeRow(this)" style="padding:0.5rem;"><i class="fa-solid fa-trash"></i></button></td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                    <div style="margin-top: 1rem; display: flex; justify-content: space-between; align-items: center; border-top: 1px solid var(--border-color); padding-top: 1rem;">
                        <button type="button" class="btn-primary" style="width: auto; background: var(--text-muted);" onclick="addRow()"><i class="fa-solid fa-plus"></i> Add Item</button>
                        <div style="text-align: right;">
                            <div style="margin-bottom: 0.5rem;">
                                <label style="font-weight: 600; margin-right: 10px;">Discount (%):</label>
                                <input type="number" name="discountPercentage" id="discountInput" value="0" min="0" max="100" step="0.1" style="width: 80px; padding: 0.5rem; border: 1px solid #cbd5e1; border-radius: 4px;" oninput="calculateTotal()">
                            </div>
                            <div style="font-size: 1.2rem; font-weight: 800;">
                                Grand Total: ₹<span id="grandTotal">0.00</span>
                                <input type="hidden" name="totalAmount" id="hiddenTotalAmount" value="0.00">
                            </div>
                        </div>
                    </div>

                    <button type="submit" class="btn-primary" style="margin-top: 2rem;">Save Bill</button>
                </form>
            </div>

            <script>
                function addRow() {
                    const tbody = document.getElementById('itemsBody');
                    const tr = document.createElement('tr');
                    tr.innerHTML = `
                            <td><input type="text" name="itemName[]" required placeholder="Item" style="width:100%; padding:0.5rem;"></td>
                            <td><input type="number" step="0.01" name="price[]" class="item-price" required placeholder="0.00" style="width:100px; padding:0.5rem;" oninput="calculateTotal()"></td>
                            <td><input type="number" name="quantity[]" class="item-qty" required value="1" min="1" style="width:80px; padding:0.5rem;" oninput="calculateTotal()"></td>
                            <td><input type="text" class="item-subtotal" readonly value="0.00" style="width:100px; padding:0.5rem; background:#f1f5f9; border:none;"></td>
                            <td><button type="button" class="btn-danger" onclick="removeRow(this)" style="padding:0.5rem;"><i class="fa-solid fa-trash"></i></button></td>
                        `;
                    tbody.appendChild(tr);
                    calculateTotal();
                }
                function removeRow(btn) {
                    if (document.querySelectorAll('#itemsBody tr').length > 1) {
                        btn.closest('tr').remove();
                        calculateTotal();
                    } else {
                        alert("You must have at least one item.");
                    }
                }
                function calculateTotal() {
                    let subtotalSum = 0;
                    const rows = document.querySelectorAll('#itemsBody tr');
                    rows.forEach(row => {
                        const price = parseFloat(row.querySelector('.item-price').value) || 0;
                        const qty = parseInt(row.querySelector('.item-qty').value) || 0;
                        const subtotal = price * qty;
                        row.querySelector('.item-subtotal').value = subtotal.toFixed(2);
                        subtotalSum += subtotal;
                    });

                    const discountPercent = parseFloat(document.getElementById('discountInput').value) || 0;
                    const finalTotal = subtotalSum * (1 - (discountPercent / 100));

                    document.getElementById('grandTotal').innerText = finalTotal.toFixed(2);
                    document.getElementById('hiddenTotalAmount').value = finalTotal.toFixed(2);
                }
                document.getElementById('billForm').addEventListener('submit', function() { calculateTotal(); });
                document.getElementById('itemsBody').addEventListener('input', function() { calculateTotal(); });
                calculateTotal();
            </script>

            <div class="card">
                <h2><i class="fa-solid fa-clock-rotate-left" style="color:var(--primary)"></i> Recent Bills for ${myShop.shopName}</h2>
                <div style="overflow-x:auto;">
                    <table>
                        <thead>
                        <tr>
                            <th>ID</th>
                            <th>Date</th>
                            <th>Customer</th>
                            <th>Phone</th>
                            <th>Amount</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <c:forEach var="bill" items="${bills}">
                            <tr>
                                <td>#${bill.id}</td>
                                <td>${bill.billDate}</td>
                                <td>${bill.customerName}</td>
                                <td>${bill.customerPhone}</td>
                                <td><strong>₹${bill.finalAmount != null ? bill.finalAmount : bill.totalAmount}</strong></td>
                                <td><span class="badge">${bill.status}</span></td>
                                <td>
                                    <a href="${pageContext.request.contextPath}/owner/bill/invoice/${bill.id}/pdf"
                                       target="_blank"
                                       style="display:inline-flex; align-items:center; gap:6px; background:#2563eb; color:white; padding:0.4rem 0.85rem; border-radius:6px; font-size:0.85rem; font-weight:600; text-decoration:none;">
                                        <i class="fa-solid fa-file-pdf"></i> PDF
                                    </a>
                                </td>
                            </tr>
                        </c:forEach>
                        <c:if test="${empty bills}">
                            <tr><td colspan="7" style="text-align:center; color:var(--text-muted); padding:2rem;">No bills generated yet.</td></tr>
                        </c:if>
                        </tbody>
                    </table>
                </div>
            </div>
        </c:when>
        <c:otherwise>
            <div class="card" style="text-align:center; color:var(--text-muted);">
                <h2>No Shop Assigned</h2>
                <p>You need to be assigned to a shop by an administrator before generating bills.</p>
            </div>
        </c:otherwise>
    </c:choose>
</div>

<!-- Announcement Toast -->
<div id="toastContainer" style="position: fixed; bottom: 20px; right: 20px; z-index: 9999;"></div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/sockjs-client/1.5.1/sockjs.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/stomp.js/2.3.3/stomp.min.js"></script>
<script>
    var stompClient = null;
    function connect() {
        var socket = new SockJS('${pageContext.request.contextPath}/ws');
        stompClient = Stomp.over(socket);
        stompClient.connect({}, function (frame) {
            stompClient.subscribe('/topic/public', function (message) {
                var data = JSON.parse(message.body);
                if (data.type === 'CHAT' && data.role === 'admin') {
                    showToast(data.content);
                }
            });
        });
    }
    function showToast(message) {
        const container = document.getElementById('toastContainer');
        const toast = document.createElement('div');
        toast.style.cssText = 'background: white; border-left: 4px solid var(--primary); padding: 15px 20px; margin-top: 10px; border-radius: 4px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); width: 300px; transform: translateX(100%); transition: 0.3s;';
        toast.innerHTML = '<h4 style="margin-bottom:5px; color:var(--text-dark);"><i class="fa-solid fa-bell" style="color:var(--primary)"></i> Admin Announcement</h4><p style="color:var(--text-muted); font-size:0.9rem;">' + message + '</p>';
        container.appendChild(toast);
        setTimeout(() => { toast.style.transform = 'translateX(0)'; }, 10);
        setTimeout(() => { toast.style.transform = 'translateX(100%)'; setTimeout(() => toast.remove(), 300); }, 6000);
    }
    connect();
</script>
</body>
</html>
