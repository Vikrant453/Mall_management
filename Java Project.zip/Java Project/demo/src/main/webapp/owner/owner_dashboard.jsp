<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html>
<head>
    <title>Owner Dashboard | Crystal Plaza</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
        :root { --primary: #f59e0b; --primary-hover: #d97706; --bg-main: #fffbeb; --card-bg: #ffffff; --text-dark: #1e293b; --text-muted: #64748b; --border-color: #f1f5f9; --danger: #ef4444; }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Inter', sans-serif; }
        body { background-color: var(--bg-main); color: var(--text-dark); line-height: 1.6; }
        .top-nav { background: var(--card-bg); padding: 0 3rem; display: flex; justify-content: space-between; align-items: center; height: 80px; border-bottom: 1px solid var(--border-color); position: sticky; top: 0; z-index: 100; box-shadow: 0 1px 3px rgba(0,0,0,0.05); }
        .nav-brand { display: flex; align-items: center; gap: 12px; font-size: 1.5rem; font-weight: 800; }
        .brand-icon { background: var(--primary); color: white; width: 36px; height: 36px; display: flex; align-items: center; justify-content: center; border-radius: 8px; }
        .nav-tabs { display: flex; gap: 2rem; height: 100%; align-items: center; }
        .nav-tab { color: var(--text-muted); font-weight: 600; transition: 0.2s; height: 100%; display: flex; align-items: center; border-bottom: 3px solid transparent; text-decoration: none; }
        .nav-tab.active, .nav-tab:hover { color: var(--text-dark); border-bottom-color: var(--primary); }
        .container { max-width: 1200px; margin: 3rem auto; padding: 0 1.5rem; }
        .dashboard-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 2rem; margin-bottom: 2rem; }
        .card { background: var(--card-bg); padding: 2rem; border-radius: 16px; border: 1px solid var(--border-color); box-shadow: 0 1px 3px rgba(0,0,0,0.05); transition: 0.3s; }
        .card-hover:hover { transform: translateY(-5px); box-shadow: 0 10px 15px -3px rgba(0,0,0,0.1); }
        .stat-card { text-align: center; }
        .stat-icon { width: 60px; height: 60px; background: #fef3c7; color: var(--primary); border-radius: 12px; display: inline-flex; align-items: center; justify-content: center; font-size: 1.8rem; margin-bottom: 1rem; }
        .stat-value { font-size: 2.2rem; font-weight: 800; color: var(--text-dark); }
        .stat-title { color: var(--text-muted); font-weight: 600; }
        .btn-primary { background: var(--primary); color: white; padding: 0.75rem 1.5rem; border: none; border-radius: 8px; font-weight: 600; cursor: pointer; transition: 0.2s; text-decoration: none; display: inline-block; }
        .btn-primary:hover { background: var(--primary-hover); }
        .btn-danger { background: var(--danger); color: white; padding: 0.75rem 1.5rem; border: none; border-radius: 8px; font-weight: 600; cursor: pointer; text-decoration: none; display: inline-block; }
        .form-group { margin-bottom: 1.2rem; }
        .form-group label { display: block; font-weight: 600; margin-bottom: 0.5rem; }
        .form-group input { width: 100%; padding: 0.75rem; border: 1px solid #cbd5e1; border-radius: 8px; font-size: 1rem; }
        .alert-success { background: #d1fae5; color: #065f46; padding: 1rem; border-radius: 8px; margin-bottom: 2rem; font-weight: 600; }
        h2 { font-weight: 800; margin-bottom: 1.5rem; }
    </style>
</head>
<body>
    <nav class="top-nav">
        <div class="nav-tabs">
            <a href="${pageContext.request.contextPath}/owner/dashboard" class="nav-tab active">Overview</a>
            <a href="${pageContext.request.contextPath}/owner/inventory" class="nav-tab">Inventory</a>
            <a href="${pageContext.request.contextPath}/owner/staff" class="nav-tab">Employees</a>
            <a href="${pageContext.request.contextPath}/owner/bills" class="nav-tab">Generate Bill</a>
            <a href="${pageContext.request.contextPath}/owner/reports" class="nav-tab">Reports</a>
            <a href="${pageContext.request.contextPath}/owner/notifications" class="nav-tab">Notifications</a>
        </div>
        <div style="display:flex; align-items:center; gap:1.5rem;">
            <div class="nav-brand">
                <div class="brand-icon">CP</div>
                Crystal Plaza
            </div>
            <a href="${pageContext.request.contextPath}/logout" class="btn-danger" title="Logout">
                <i class="fa-solid fa-right-from-bracket"></i>
            </a>
        </div>
    </nav>
    <div class="container">
        <div style="text-align: center; margin-bottom: 3rem;">
            <h2 style="font-size: 2.2rem;">Welcome, ${username}! 👋</h2>
            <c:choose>
                <c:when test="${not empty myShop}">
                    <p style="color: var(--text-muted); font-size: 1.1rem;">Managing: <strong>${myShop.shopName}</strong> (${myShop.category})</p>
                </c:when>
                <c:otherwise>
                    <p style="color: var(--danger);">No shop assigned to you yet. Please contact the administrator.</p>
                </c:otherwise>
            </c:choose>
        </div>

        <c:if test="${not empty param.success}">
            <div class="alert-success"><i class="fa-solid fa-check-circle"></i> ${param.success}</div>
        </c:if>

        <c:if test="${not empty lowStockCount and lowStockCount > 0}">
            <div class="alert-success" style="background: #fef2f2; color: #991b1b; border: 1px solid #fecaca;">
                <i class="fa-solid fa-triangle-exclamation"></i> <strong>Inventory Alert:</strong> You have ${lowStockCount} item(s) running low on stock (Quantity < 5). 
                <a href="${pageContext.request.contextPath}/owner/inventory" style="color: #991b1b; font-weight: bold; text-decoration: underline;">Review Inventory</a>
            </div>
        </c:if>

        <c:if test="${not empty myShop}">
            <div class="dashboard-grid">
                <a href="${pageContext.request.contextPath}/owner/reports" class="card card-hover stat-card" style="text-decoration:none;">
                    <div class="stat-icon" style="background:#dcfce7; color:#16a34a;"><i class="fa-solid fa-indian-rupee-sign"></i></div>
                    <div class="stat-title">Shop Revenue</div>
                    <div class="stat-value" style="color:#16a34a">₹${shopRevenue}</div>
                </a>
                <a href="${pageContext.request.contextPath}/owner/bills" class="card card-hover stat-card" style="text-decoration:none;">
                    <div class="stat-icon" style="background:#e0e7ff; color:#4f46e5;"><i class="fa-solid fa-file-invoice"></i></div>
                    <div class="stat-title">Total Bills Generated</div>
                    <div class="stat-value" style="color:#4f46e5">${totalBills}</div>
                </a>
                <div class="card stat-card">
                    <div class="stat-icon"><i class="fa-solid fa-bullhorn"></i></div>
                    <div class="stat-title">Active Offer</div>
                    <div class="stat-value" style="font-size:1.5rem; margin-top:10px;">
                        <c:choose>
                            <c:when test="${not empty myOffer}">
                                <span style="color:var(--primary)">${myOffer.discountPercent}% OFF</span>
                            </c:when>
                            <c:otherwise>
                                <span style="color:var(--text-muted); font-size:1.2rem;">None</span>
                            </c:otherwise>
                        </c:choose>
                    </div>
                </div>
            </div>

            <div class="dashboard-grid" style="grid-template-columns: 1fr 1fr;">
                <div class="card">
                    <h2><i class="fa-solid fa-tags" style="color:var(--primary)"></i> Manage Store Offer</h2>
                    <p style="color:var(--text-muted); margin-bottom:1.5rem;">Update the deal shown on the Customer Dashboard.</p>
                    
                    <c:choose>
                        <c:when test="${not empty myOffer}">
                            <div style="background:#fffbeb; padding:1.5rem; border-radius:12px; border:1px dashed var(--primary); margin-bottom:1.5rem;">
                                <strong>Current Offer:</strong> ${myOffer.offerText} <br>
                                <strong>Discount:</strong> ${myOffer.discountPercent}% OFF
                            </div>
                            <form action="${pageContext.request.contextPath}/owner/offer/delete/${myShop.id}" method="post">
                                <button type="submit" class="btn-danger"><i class="fa-solid fa-trash"></i> Remove Offer</button>
                            </form>
                        </c:when>
                        <c:otherwise>
                            <form action="${pageContext.request.contextPath}/owner/offer/save" method="post">
                                <input type="hidden" name="shopId" value="${myShop.id}">
                                <div class="form-group">
                                    <label>Offer Details</label>
                                    <input type="text" name="offerText" placeholder="e.g. Buy 1 Get 1 Free on all T-Shirts!" required>
                                </div>
                                <div class="form-group">
                                    <label>Discount Percentage</label>
                                    <input type="number" name="discountPercent" min="0" max="100" placeholder="e.g. 20" required>
                                </div>
                                <button type="submit" class="btn-primary">Publish Offer</button>
                            </form>
                        </c:otherwise>
                    </c:choose>
                </div>
                
                <div class="card">
                    <h2><i class="fa-solid fa-bolt" style="color:var(--primary)"></i> Quick Actions</h2>
                    <div style="display:flex; flex-direction:column; gap:1rem;">
                        <a href="${pageContext.request.contextPath}/owner/bills" class="btn-primary" style="text-align:center;"><i class="fa-solid fa-file-invoice"></i> Generate New Bill</a>
                        <a href="${pageContext.request.contextPath}/owner/reports" class="btn-primary" style="text-align:center; background:var(--text-dark);"><i class="fa-solid fa-chart-line"></i> View Sales Report</a>
                    </div>
                </div>
            </div>
        </c:if>
    </div>

    <!-- Announcement Toast -->
    <div id="toastContainer" style="position: fixed; bottom: 20px; right: 20px; z-index: 9999;"></div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/sockjs-client/1.5.1/sockjs.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/stomp.js/2.3.3/stomp.min.js"></script>
    <script>
        var stompClient = null;

        function connect() {
            var socket = new SockJS('${pageContext.request.contextPath}/ws');
            stompClient = Stomp.over(socket);
            stompClient.connect({}, function (frame) {
                stompClient.subscribe('/topic/public', function (message) {
                    var data = JSON.parse(message.body);
                    if (data.type === 'CHAT' && data.role === 'admin') {
                        showToast(data.content);
                    }
                });
            });
        }

        function showToast(message) {
            const container = document.getElementById('toastContainer');
            const toast = document.createElement('div');
            toast.style.cssText = 'background: white; border-left: 4px solid var(--primary); padding: 15px 20px; margin-top: 10px; border-radius: 4px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); width: 300px; transform: translateX(100%); transition: 0.3s;';
            toast.innerHTML = '<h4 style="margin-bottom:5px; color:var(--text-dark);"><i class="fa-solid fa-bell" style="color:var(--primary)"></i> Admin Announcement</h4><p style="color:var(--text-muted); font-size:0.9rem;">' + message + '</p>';
            container.appendChild(toast);
            
            setTimeout(() => { toast.style.transform = 'translateX(0)'; }, 10);
            setTimeout(() => { 
                toast.style.transform = 'translateX(100%)'; 
                setTimeout(() => { toast.remove(); }, 300);
            }, 6000);
        }

        connect();
    </script>
</body>
</html>
