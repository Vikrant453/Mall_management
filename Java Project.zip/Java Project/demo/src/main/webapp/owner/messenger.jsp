<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html>
<head>
    <title>Messenger | Crystal Plaza</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
        :root { --primary: #f59e0b; --primary-hover: #d97706; --bg-main: #fffbeb; --card-bg: #ffffff; --text-dark: #1e293b; --text-muted: #64748b; --border-color: #f1f5f9; --danger: #ef4444; }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Inter', sans-serif; }
        body { background-color: var(--bg-main); color: var(--text-dark); line-height: 1.6; display: flex; flex-direction: column; height: 100vh; }
        .top-nav { background: var(--card-bg); padding: 0 3rem; display: flex; justify-content: space-between; align-items: center; height: 80px; border-bottom: 1px solid var(--border-color); flex-shrink: 0; box-shadow: 0 1px 3px rgba(0,0,0,0.05); }
        .nav-tabs { display: flex; gap: 2rem; height: 100%; align-items: center; }
        .nav-tab { color: var(--text-muted); font-weight: 600; transition: 0.2s; height: 100%; display: flex; align-items: center; border-bottom: 3px solid transparent; text-decoration: none; }
        .nav-tab.active, .nav-tab:hover { color: var(--text-dark); border-bottom-color: var(--primary); }
        .nav-brand { display: flex; align-items: center; gap: 12px; font-size: 1.5rem; font-weight: 800; }
        .container { flex: 1; max-width: 1000px; width: 100%; margin: 2rem auto; padding: 0 1.5rem; display: flex; flex-direction: column; }
        
        .chat-container { background: var(--card-bg); border-radius: 16px; border: 1px solid var(--border-color); box-shadow: 0 4px 6px rgba(0,0,0,0.05); display: flex; flex-direction: column; flex: 1; overflow: hidden; }
        .chat-header { padding: 1.5rem; border-bottom: 1px solid var(--border-color); background: #fdfaf0; }
        .chat-header h2 { font-weight: 800; display: flex; align-items: center; gap: 10px; }
        
        .chat-messages { flex: 1; padding: 1.5rem; overflow-y: auto; display: flex; flex-direction: column; gap: 1rem; background: #fdfaf0; }
        .message { max-width: 75%; padding: 1rem; border-radius: 12px; position: relative; }
        .message-other { background: white; align-self: flex-start; border-bottom-left-radius: 0; box-shadow: 0 1px 2px rgba(0,0,0,0.05); border: 1px solid var(--border-color); }
        .message-mine { background: var(--primary); color: white; align-self: flex-end; border-bottom-right-radius: 0; }
        .message-sender { font-weight: 700; font-size: 0.85rem; margin-bottom: 4px; display: block; }
        .message-other .message-sender { color: var(--primary); }
        .message-mine .message-sender { color: #fffbeb; }
        .message-time { font-size: 0.75rem; opacity: 0.7; margin-top: 5px; text-align: right; display: block; }
        
        .chat-input { padding: 1.5rem; border-top: 1px solid var(--border-color); display: flex; gap: 1rem; background: white; }
        .chat-input input { flex: 1; padding: 1rem; border: 1px solid var(--border-color); border-radius: 999px; font-size: 1rem; outline: none; }
        .chat-input input:focus { border-color: var(--primary); }
        .chat-input button { background: var(--primary); color: white; width: 50px; height: 50px; border-radius: 50%; border: none; font-size: 1.2rem; cursor: pointer; transition: 0.2s; display: flex; align-items: center; justify-content: center; }
        .chat-input button:hover { background: var(--primary-hover); transform: scale(1.05); }
    </style>
    <!-- SockJS and STOMP -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sockjs-client/1.6.1/sockjs.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/stomp.js/2.3.3/stomp.min.js"></script>
</head>
<body>
    <nav class="top-nav">
        <div class="nav-tabs">
            <a href="${pageContext.request.contextPath}/owner/dashboard" class="nav-tab">Overview</a>
            <a href="${pageContext.request.contextPath}/owner/inventory" class="nav-tab">Inventory</a>
            <a href="${pageContext.request.contextPath}/owner/bills" class="nav-tab">Generate Bill</a>
            <a href="${pageContext.request.contextPath}/owner/reports" class="nav-tab">Reports</a>
            <a href="${pageContext.request.contextPath}/owner/messenger" class="nav-tab active">Messenger</a>
        </div>
        <div style="display:flex; align-items:center; gap:1.5rem;">
            <div class="nav-brand">
                <div class="brand-icon">CP</div>
                Crystal Plaza
            </div>
            <a href="${pageContext.request.contextPath}/logout" class="nav-tab" style="color: #ef4444;" title="Logout">
                <i class="fa-solid fa-right-from-bracket"></i>
            </a>
        </div>
    </nav>
    
    <div class="container">
        <div class="chat-container">
            <div class="chat-header">
                <h2><i class="fa-brands fa-whatsapp" style="color: #25d366; font-size:1.8rem;"></i> Global Support Chat</h2>
                <p style="color: var(--text-muted); font-size: 0.9rem;">Real-time communication between Administrators and Shop Owners.</p>
            </div>
            <div class="chat-messages" id="chatArea">
                <c:forEach var="msg" items="${messages}">
                    <div class="message ${msg.sender eq (username += ' (Owner)') ? 'message-mine' : 'message-other'}">
                        <span class="message-sender">${msg.sender}</span>
                        <span>${msg.content}</span>
                        <span class="message-time">${msg.timestamp}</span>
                    </div>
                </c:forEach>
            </div>
            <div class="chat-input">
                <input type="text" id="messageInput" placeholder="Type a message..." onkeypress="if(event.key === 'Enter') sendMessage()">
                <button onclick="sendMessage()"><i class="fa-solid fa-paper-plane"></i></button>
            </div>
        </div>
    </div>

    <script>
        var stompClient = null;
        var myUsername = "${username} (Owner)";

        function connect() {
            var socket = new SockJS('${pageContext.request.contextPath}/ws');
            stompClient = Stomp.over(socket);
            stompClient.connect({}, function (frame) {
                console.log('Connected: ' + frame);
                stompClient.subscribe('/topic/public', function (message) {
                    showMessage(JSON.parse(message.body));
                });
            });
            setTimeout(() => {
                var chatArea = document.getElementById("chatArea");
                chatArea.scrollTop = chatArea.scrollHeight;
            }, 100);
        }

        function sendMessage() {
            var content = document.getElementById("messageInput").value.trim();
            if(content && stompClient) {
                var chatMessage = {
                    sender: myUsername,
                    content: content
                };
                stompClient.send("/app/chat.sendMessage", {}, JSON.stringify(chatMessage));
                document.getElementById("messageInput").value = '';
            }
        }

        function showMessage(message) {
            var chatArea = document.getElementById("chatArea");
            var messageElement = document.createElement("div");
            
            if (message.sender === myUsername) {
                messageElement.className = "message message-mine";
            } else {
                messageElement.className = "message message-other";
            }
            
            messageElement.innerHTML = 
                "<span class='message-sender'>" + message.sender + "</span>" +
                "<span>" + message.content + "</span>" +
                "<span class='message-time'>" + message.timestamp + "</span>";
                
            chatArea.appendChild(messageElement);
            chatArea.scrollTop = chatArea.scrollHeight;
        }

        // Connect on load
        connect();
    </script>
</body>
</html>
