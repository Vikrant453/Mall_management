<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
    <%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
        <!DOCTYPE html>
        <html>

        <head>
            <title>Login | Crystal Plaza</title>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
            <style>
                @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');

                :root {
                    --primary: #2563eb;
                    --bg-main: #f0f9ff;
                    --card-bg: #ffffff;
                    --text-dark: #0f172a;
                    --text-muted: #475569;
                    --border-color: #e2e8f0;
                    --danger: #ef4444;
                }

                * {
                    margin: 0;
                    padding: 0;
                    box-sizing: border-box;
                    font-family: 'Inter', sans-serif;
                }

                body {
                    background-color: var(--bg-main);
                    color: var(--text-dark);
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    min-height: 100vh;
                    flex-direction: column;
                }

                .login-card {
                    background: var(--card-bg);
                    padding: 3rem;
                    border-radius: 20px;
                    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.05);
                    width: 100%;
                    max-width: 400px;
                    text-align: center;
                }

                .brand-icon {
                    background: var(--primary);
                    color: white;
                    width: 60px;
                    height: 60px;
                    display: inline-flex;
                    align-items: center;
                    justify-content: center;
                    border-radius: 14px;
                    font-size: 2rem;
                    font-weight: 800;
                    margin-bottom: 1rem;
                }

                h2 {
                    font-weight: 800;
                    margin-bottom: 0.5rem;
                }

                p {
                    color: var(--text-muted);
                    margin-bottom: 2rem;
                }

                .form-group {
                    text-align: left;
                    margin-bottom: 1.5rem;
                }

                .form-group label {
                    display: block;
                    font-weight: 600;
                    margin-bottom: 0.5rem;
                    color: var(--text-dark);
                }

                .form-group input {
                    width: 100%;
                    padding: 0.75rem 1rem;
                    border: 1px solid var(--border-color);
                    border-radius: 10px;
                    font-size: 1rem;
                    outline: none;
                    transition: border-color 0.3s;
                }

                .form-group input:focus {
                    border-color: var(--primary);
                }

                .btn-login {
                    width: 100%;
                    padding: 0.85rem;
                    background: var(--primary);
                    color: white;
                    border: none;
                    border-radius: 10px;
                    font-size: 1.1rem;
                    font-weight: 600;
                    cursor: pointer;
                    transition: 0.3s;
                    margin-bottom: 1.5rem;
                }

                .btn-login:hover {
                    background: #1d4ed8;
                    transform: translateY(-2px);
                }

                .error-msg {
                    background: #fee2e2;
                    color: var(--danger);
                    padding: 0.75rem;
                    border-radius: 8px;
                    margin-bottom: 1.5rem;
                    font-weight: 500;
                    font-size: 0.9rem;
                }

                .portals {
                    display: flex;
                    justify-content: space-between;
                    font-size: 0.85rem;
                    color: var(--text-muted);
                    margin-bottom: 1.5rem;
                }

                .customer-link:hover {
                    text-decoration: underline;
                }

                .role-switch {
                    display: flex;
                    background: var(--bg-main);
                    border-radius: 8px;
                    padding: 4px;
                    margin-bottom: 1.5rem;
                }

                .role-switch input {
                    display: none;
                }

                .role-switch label {
                    flex: 1;
                    text-align: center;
                    padding: 0.5rem;
                    border-radius: 6px;
                    cursor: pointer;
                    font-weight: 600;
                    font-size: 0.9rem;
                    color: var(--text-muted);
                    transition: 0.3s;
                }

                .role-switch input:checked+label {
                    background: var(--card-bg);
                    color: var(--primary);
                    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
                }

                .footer-info {
                    margin-top: 2rem;
                    font-size: 0.8rem;
                    color: var(--text-muted);
                    line-height: 1.5;
                    border-top: 1px solid var(--border-color);
                    padding-top: 1.5rem;
                }

                .footer-info strong {
                    color: var(--text-dark);
                }
            </style>
        </head>

        <body>
            <div class="login-card">
                <div class="brand-icon">CP</div>
                <h2>Welcome to Crystal Plaza</h2>


                <div class="role-switch">
                    <input type="radio" id="role-admin" name="roleDisplay" checked>
                    <label for="role-admin">Administrator</label>
                    <input type="radio" id="role-owner" name="roleDisplay">
                    <label for="role-owner">Shop Owner</label>
                </div>

                <c:if test="${not empty param.error}">
                    <div class="error-msg">
                        <i class="fa-solid fa-circle-exclamation"></i> Invalid username or password.
                    </div>
                </c:if>

                <form action="${pageContext.request.contextPath}/login" method="post">
                    <div class="form-group">
                        <label for="username">Username</label>
                        <input type="text" id="username" name="username" required autocomplete="off">
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <div style="position: relative; display: flex; align-items: center;">
                            <input type="password" id="password" name="password" required style="padding-right: 2.5rem;">
                            <i class="fa-solid fa-eye" id="togglePassword" style="position: absolute; right: 10px; cursor: pointer; color: var(--text-muted);"></i>
                        </div>
                    </div>
                    <button type="submit" class="btn-login">Login <i
                            class="fa-solid fa-arrow-right-to-bracket"></i></button>
                </form>

                <div style="margin-top: 1.5rem;">
                    <a href="${pageContext.request.contextPath}/customer/dashboard" class="customer-link">Continue as
                        Customer →</a>
                </div>

                <div class="footer-info">
                    <p><strong>Crystal Plaza. Neo-Genesis Galleria</strong><br>
                        901 Sky-Line Drive<br>
                        District 5, Sector B<br>
                        Mumbai, Maharashtra 400001<br>
                        India</p>
                    <p style="margin-top: 10px;">&copy; Design Copyright. All Rights Reserved.</p>
                </div>
            </div>
            
            <script>
                const togglePassword = document.querySelector('#togglePassword');
                const password = document.querySelector('#password');

                togglePassword.addEventListener('click', function (e) {
                    const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
                    password.setAttribute('type', type);
                    this.classList.toggle('fa-eye-slash');
                });
            </script>
        </body>
        </html>