<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/fmt" prefix="fmt" %>
<!DOCTYPE html>
<html>
<head>
    <title>Financial Reports | Crystal Plaza</title>
    <!-- Chart.js and HTML2PDF -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
        :root { --primary: #2563eb; --primary-hover: #1d4ed8; --bg-main: #f0f9ff; --card-bg: #ffffff; --text-dark: #0f172a; --text-muted: #475569; --border-color: #e2e8f0; --success: #10b981; }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Inter', sans-serif; }
        body { background-color: var(--bg-main); color: var(--text-dark); line-height: 1.6; }
        .top-nav { background: var(--card-bg); padding: 0 3rem; display: flex; justify-content: space-between; align-items: center; height: 80px; border-bottom: 1px solid var(--border-color); position: sticky; top: 0; z-index: 100; }
        .nav-brand { display: flex; align-items: center; gap: 12px; font-size: 1.5rem; font-weight: 800; }
        .brand-icon { background: var(--primary); color: white; width: 36px; height: 36px; display: flex; align-items: center; justify-content: center; border-radius: 8px; }
        .nav-tabs { display: flex; gap: 2rem; height: 100%; align-items: center; }
        .nav-tab { color: var(--text-muted); font-weight: 600; transition: 0.2s; height: 100%; display: flex; align-items: center; border-bottom: 3px solid transparent; text-decoration: none; }
        .nav-tab.active, .nav-tab:hover { color: var(--text-dark); border-bottom-color: var(--primary); }
        .container { max-width: 1200px; margin: 3rem auto; padding: 0 1.5rem; }
        .summary-row { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1.5rem; margin-bottom: 2rem; }
        .stat-card { background: var(--card-bg); padding: 2rem; border-radius: 16px; border: 1px solid var(--border-color); box-shadow: 0 1px 3px rgba(0,0,0,0.05); }
        .stat-title { color: var(--text-muted); font-weight: 600; font-size: 0.9rem; text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 0.5rem; }
        .stat-value { font-size: 2.2rem; font-weight: 800; color: var(--text-dark); }
        .card { background: var(--card-bg); padding: 2rem; border-radius: 16px; border: 1px solid var(--border-color); box-shadow: 0 1px 3px rgba(0,0,0,0.05); }
        .card-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; }
        h2 { font-weight: 800; }
        .btn-primary { background: var(--primary); color: white; padding: 0.75rem 1.5rem; border: none; border-radius: 8px; font-weight: 600; cursor: pointer; transition: 0.2s; text-decoration: none; display: inline-flex; align-items: center; gap: 8px; }
        .btn-primary:hover { background: var(--primary-hover); }
        table { width: 100%; border-collapse: collapse; margin-top: 1rem; }
        th, td { padding: 1rem; text-align: left; border-bottom: 1px solid var(--border-color); }
        th { font-weight: 700; color: var(--text-muted); text-transform: uppercase; font-size: 0.85rem; letter-spacing: 0.05em; }
        tr:hover { background: #f8fafc; }
        .badge { background: #d1fae5; color: #065f46; padding: 0.25rem 0.75rem; border-radius: 999px; font-size: 0.85rem; font-weight: 600; }
        .alert-info { background: #eff6ff; color: #1e40af; padding: 1rem; border-radius: 8px; margin-bottom: 2rem; font-weight: 600; }
    </style>
</head>
<body>
    <nav class="top-nav">
        <div class="nav-tabs">
            <a href="${pageContext.request.contextPath}/admin/dashboard" class="nav-tab">Overview</a>
            <a href="${pageContext.request.contextPath}/admin/manage-shops" class="nav-tab">Shops</a>
            <a href="${pageContext.request.contextPath}/admin/manage-owners" class="nav-tab">Owners</a>
            <a href="${pageContext.request.contextPath}/admin/reports" class="nav-tab active">Financials</a>
            <a href="${pageContext.request.contextPath}/admin/messenger" class="nav-tab">Messenger</a>
        </div>
        <div style="display:flex; align-items:center; gap:1.5rem;">
            <div class="nav-brand">
                <div class="brand-icon">CP</div>
                Crystal Plaza
            </div>
            <a href="${pageContext.request.contextPath}/logout" class="btn-primary" style="background:var(--danger)" title="Logout">
                <i class="fa-solid fa-right-from-bracket"></i>
            </a>
        </div>
    </nav>
    <div class="container" id="report-content">
        <c:if test="${not empty param.msg}">
            <div class="alert-info"><i class="fa-solid fa-info-circle"></i> ${param.msg}</div>
        </c:if>

        <div class="summary-row">
            <div class="stat-card">
                <div class="stat-title">Total Gross Revenue</div>
                <div class="stat-value" style="color: var(--success)">₹${totalRevenue}</div>
            </div>
            <div class="stat-card">
                <div class="stat-title">Total Bills Generated</div>
                <div class="stat-value">${totalBills}</div>
            </div>
            <div class="stat-card">
                <div class="stat-title">Active Shops</div>
                <div class="stat-value">${totalShops}</div>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h2><i class="fa-solid fa-chart-bar" style="color:var(--primary)"></i> Revenue Graph Analytics</h2>
                <button type="button" class="btn-primary" onclick="exportPDF()"><i class="fa-solid fa-file-pdf"></i> Export to PDF</button>
            </div>
            <div style="height: 400px; width: 100%; margin-bottom: 3rem;">
                <canvas id="revenueChart"></canvas>
            </div>
            
            <div class="card-header">
                <h2><i class="fa-solid fa-file-invoice" style="color:var(--primary)"></i> Master Transaction Log</h2>
            </div>
            <div style="overflow-x:auto;">
                <table>
                    <thead>
                        <tr>
                            <th>Bill ID</th>
                            <th>Date</th>
                            <th>Customer Name</th>
                            <th>Customer Phone</th>
                            <th>Shop</th>
                            <th>Amount</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <c:forEach var="bill" items="${bills}">
                            <tr>
                                <td>#${bill.id}</td>
                                <td>${bill.billDate}</td>
                                <td>${bill.customerName}</td>
                                <td>${bill.customerPhone}</td>
                                <td><strong>${bill.shop.shopName}</strong></td>
                                <td><strong style="color:var(--success)">₹${bill.totalAmount}</strong></td>
                                <td><span class="badge">${bill.status}</span></td>
                            </tr>
                        </c:forEach>
                        <c:if test="${empty bills}">
                            <tr><td colspan="7" style="text-align:center; color:var(--text-muted); padding:2rem;">No transactions recorded.</td></tr>
                        </c:if>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <script>
        // Chart.js Setup
        const ctx = document.getElementById('revenueChart').getContext('2d');
        const shopLabels = [];
        const shopData = [];
        
        <c:forEach items="${shopRevenues}" var="entry">
            shopLabels.push('${entry.key}');
            shopData.push(${entry.value});
        </c:forEach>

        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: shopLabels,
                datasets: [{
                    label: 'Gross Revenue (₹)',
                    data: shopData,
                    backgroundColor: 'rgba(37, 99, 235, 0.6)',
                    borderColor: 'rgba(37, 99, 235, 1)',
                    borderWidth: 1,
                    borderRadius: 4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: { y: { beginAtZero: true } }
            }
        });

        // PDF Export
        function exportPDF() {
            const element = document.getElementById('report-content');
            const opt = {
                margin:       0.5,
                filename:     'CrystalPlaza_FinancialReport.pdf',
                image:        { type: 'jpeg', quality: 0.98 },
                html2canvas:  { scale: 2 },
                jsPDF:        { unit: 'in', format: 'letter', orientation: 'portrait' }
            };
            html2pdf().set(opt).from(element).save();
        }
    </script>
</body>
</html>
