<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Overview | Crystal Plaza</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
        :root { --primary: #2563eb; --primary-hover: #1d4ed8; --bg-main: #f0f9ff; --card-bg: #ffffff; --text-dark: #0f172a; --text-muted: #475569; --border-color: #e2e8f0; --danger: #ef4444; --success: #10b981; }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Inter', sans-serif; }
        body { background-color: var(--bg-main); color: var(--text-dark); line-height: 1.6; }
        .top-nav { background: var(--card-bg); padding: 0 3rem; display: flex; justify-content: space-between; align-items: center; height: 80px; border-bottom: 1px solid var(--border-color); position: sticky; top: 0; z-index: 100; }
        .nav-brand { display: flex; align-items: center; gap: 12px; font-size: 1.5rem; font-weight: 800; }
        .brand-icon { background: var(--primary); color: white; width: 36px; height: 36px; display: flex; align-items: center; justify-content: center; border-radius: 8px; }
        .nav-tabs { display: flex; gap: 2rem; height: 100%; align-items: center; }
        .nav-tab { color: var(--text-muted); font-weight: 600; transition: 0.2s; height: 100%; display: flex; align-items: center; border-bottom: 3px solid transparent; text-decoration: none; }
        .nav-tab.active, .nav-tab:hover { color: var(--text-dark); border-bottom-color: var(--primary); }
        .container { max-width: 1200px; margin: 3rem auto; padding: 0 1.5rem; }
        .dashboard-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 2rem; }
        .card { background: var(--card-bg); padding: 2.5rem 2rem; border-radius: 16px; border: 1px solid var(--border-color); box-shadow: 0 1px 3px rgba(0,0,0,0.05); transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1); text-decoration: none; color: inherit; text-align: center; display: flex; flex-direction: column; align-items: center; }
        .card:hover { transform: translateY(-10px) scale(1.03); box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1); border-color: #cbd5e1; }
        .card-icon { width: 60px; height: 60px; background: #eff6ff; color: var(--primary); border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 1.8rem; margin-bottom: 1.5rem; }
        .value { font-size: 2.5rem; font-weight: 800; color: var(--primary); margin-top: 1rem; }
        .btn-logout { background: var(--danger); color: white; padding: 0.6rem 1.2rem; border-radius: 8px; font-weight: 600; text-decoration: none; transition: 0.3s; }
        .btn-logout:hover { opacity: 0.9; transform: translateY(-1px); }
    </style>
</head>
<body>
    <nav class="top-nav">
        <div class="nav-tabs">
            <a href="${pageContext.request.contextPath}/admin/dashboard" class="nav-tab active">Overview</a>
            <a href="${pageContext.request.contextPath}/admin/manage-shops" class="nav-tab">Shops</a>
            <a href="${pageContext.request.contextPath}/admin/manage-owners" class="nav-tab">Owners</a>
            <a href="${pageContext.request.contextPath}/admin/reports" class="nav-tab">Financials</a>
            <a href="${pageContext.request.contextPath}/admin/messenger" class="nav-tab">Messenger</a>
        </div>
        <div style="display:flex; align-items:center; gap:1.5rem;">
            <div class="nav-brand">
                <div class="brand-icon">CP</div>
                Crystal Plaza
            </div>
            <a href="${pageContext.request.contextPath}/logout" class="btn-logout" title="Logout">
                <i class="fa-solid fa-right-from-bracket"></i>
            </a>
        </div>
    </nav>
    <div class="container">
        <div style="text-align: center; margin-bottom: 3rem;">
            <h2 style="font-size: 2.2rem; font-weight: 800;">Crystal Plaza Operations Center</h2>
            <p style="color: var(--text-muted);">Real-time monitoring of all mall activities</p>
        </div>
        <div class="dashboard-grid">
            <a href="${pageContext.request.contextPath}/admin/manage-shops" class="card">
                <div class="card-icon"><i class="fa-solid fa-store"></i></div>
                <h3>Active Shops</h3><p>Manage store leases and categories.</p>
                <div class="value">${activeShops}</div>
            </a>
            <a href="${pageContext.request.contextPath}/admin/manage-owners" class="card">
                <div class="card-icon"><i class="fa-solid fa-users-gear"></i></div>
                <h3>Registered Owners</h3><p>Assign and manage shop owners.</p>
                <div class="value">${registeredOwners}</div>
            </a>
            <a href="${pageContext.request.contextPath}/admin/reports" class="card">
                <div class="card-icon" style="color:var(--success); background:#ecfdf5;"><i class="fa-solid fa-indian-rupee-sign"></i></div>
                <h3>Gross Revenue</h3><p>Total earnings across all floors.</p>
                <div class="value" style="color:var(--success)">₹${grossRevenue}</div>
            </a>
            <a href="${pageContext.request.contextPath}/admin/reports" class="card">
                <div class="card-icon" style="color:#8b5cf6; background:#f5f3ff;"><i class="fa-solid fa-file-invoice"></i></div>
                <h3>Total Bills</h3><p>Transactions processed.</p>
                <div class="value" style="color:#8b5cf6">${totalBills}</div>
            </a>
        </div>
    </div>
</body>
</html>
