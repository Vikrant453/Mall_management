<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>Parking Status | ParkSmart</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
        :root { --primary: #2563eb; --bg-main: #f0f9ff; --card-bg: #ffffff; --text-dark: #0f172a; --text-muted: #475569; --border-color: #e2e8f0; --success: #10b981; --warning: #f59e0b; --danger: #ef4444; }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Inter', sans-serif; }
        body { background-color: var(--bg-main); color: var(--text-dark); line-height: 1.6; }
        .top-nav { background: var(--card-bg); padding: 0 3rem; display: flex; justify-content: space-between; align-items: center; height: 80px; border-bottom: 1px solid var(--border-color); position: sticky; top: 0; z-index: 100; box-shadow: 0 1px 3px rgba(0,0,0,0.05); }
        .nav-brand { display: flex; align-items: center; gap: 12px; font-size: 1.5rem; font-weight: 800; color: var(--text-dark); width: 250px; }
        .brand-icon { background: var(--primary); color: white; width: 36px; height: 36px; display: flex; align-items: center; justify-content: center; border-radius: 8px; font-size: 1.2rem; }
        .nav-tabs { display: flex; gap: 2rem; height: 100%; align-items: center; justify-content: center; flex: 1; }
        .nav-tab { color: var(--text-muted); font-weight: 600; transition: color 0.2s; height: 100%; display: flex; align-items: center; border-bottom: 3px solid transparent; text-decoration: none; }
        .nav-tab:hover { color: var(--primary); }
        .nav-tab.active { color: var(--text-dark); border-bottom-color: var(--primary); }
        .nav-actions { width: 250px; display: flex; justify-content: flex-end; }
        .btn-outline { padding: 0.6rem 1.5rem; border-radius: 8px; font-weight: 600; border: 2px solid var(--primary); color: var(--primary); text-decoration: none; transition: 0.2s; }
        .btn-outline:hover { background: var(--primary); color: white; }
        .container { max-width: 800px; margin: 3rem auto; padding: 0 1.5rem; }
        h2 { font-weight: 800; margin-bottom: 2rem; font-size: 2rem; text-align: center; }
        .parking-card { background: var(--card-bg); padding: 2rem; border-radius: 16px; border: 1px solid var(--border-color); box-shadow: 0 4px 6px rgba(0,0,0,0.05); margin-bottom: 1.5rem; display: flex; justify-content: space-between; align-items: center; }
        .level-info h3 { font-size: 1.4rem; font-weight: 700; margin-bottom: 0.25rem; }
        .level-info p { color: var(--text-muted); font-size: 0.95rem; }
        .progress-container { width: 300px; background: #e2e8f0; border-radius: 999px; height: 12px; overflow: hidden; margin-top: 10px; }
        .progress-bar { height: 100%; border-radius: 999px; transition: width 1s ease-in-out; }
        .status-badge { padding: 0.4rem 1rem; border-radius: 8px; font-weight: 700; font-size: 0.9rem; text-transform: uppercase; letter-spacing: 0.05em; }
    </style>
</head>
<body>
    <nav class="top-nav">
        <div class="nav-brand"><div class="brand-icon">P</div> ParkSmart</div>
        <div class="nav-tabs">
            <a href="${pageContext.request.contextPath}/customer/dashboard" class="nav-tab">Home</a>
            <a href="${pageContext.request.contextPath}/customer/shops" class="nav-tab">Store Directory</a>
            <a href="${pageContext.request.contextPath}/customer/parking" class="nav-tab active">Parking</a>
        </div>
        <div class="nav-actions"><a href="${pageContext.request.contextPath}/auth/login.jsp" class="btn-outline">Staff Portal</a></div>
    </nav>
    <div class="container">
        <h2><i class="fa-solid fa-square-parking" style="color:var(--primary)"></i> Real-Time Parking Status</h2>
        
        <div class="parking-card">
            <div class="level-info">
                <h3>Ground Floor (P1)</h3>
                <p>Premium & Handicapped Parking</p>
                <div class="progress-container">
                    <div class="progress-bar" style="width: 45%; background: var(--success);"></div>
                </div>
                <p style="margin-top:5px; font-weight:600;">45 / 100 Spaces Filled</p>
            </div>
            <div class="status-badge" style="background:#d1fae5; color:#065f46;">Available</div>
        </div>

        <div class="parking-card">
            <div class="level-info">
                <h3>Basement Level 1 (P2)</h3>
                <p>Standard Parking</p>
                <div class="progress-container">
                    <div class="progress-bar" style="width: 37.5%; background: var(--success);"></div>
                </div>
                <p style="margin-top:5px; font-weight:600;">30 / 80 Spaces Filled</p>
            </div>
            <div class="status-badge" style="background:#d1fae5; color:#065f46;">Available</div>
        </div>

        <div class="parking-card">
            <div class="level-info">
                <h3>Basement Level 2 (P3)</h3>
                <p>Extended Parking</p>
                <div class="progress-container">
                    <div class="progress-bar" style="width: 100%; background: var(--danger);"></div>
                </div>
                <p style="margin-top:5px; font-weight:600;">60 / 60 Spaces Filled</p>
            </div>
            <div class="status-badge" style="background:#fee2e2; color:#b91c1c;">Full</div>
        </div>
        
        <p style="text-align: center; color: var(--text-muted); margin-top: 2rem;">
            <i class="fa-solid fa-circle-info"></i> Status is automatically updated every minute.
        </p>
    </div>
</body>
</html>
