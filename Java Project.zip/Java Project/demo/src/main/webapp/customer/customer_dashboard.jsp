<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html>
<head>
    <title>Crystal Plaza Dashboard</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
        :root { --primary: #2563eb; --bg-main: #f0f9ff; --card-bg: #ffffff; --text-dark: #0f172a; --text-muted: #475569; --border-color: #e2e8f0; }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Inter', sans-serif; }
        body { background-color: var(--bg-main); color: var(--text-dark); line-height: 1.6; overflow-x: hidden; }
        a { text-decoration: none; color: var(--primary); font-weight: 500; }
        
        .top-nav { background: var(--card-bg); padding: 0 3rem; display: flex; justify-content: space-between; align-items: center; height: 80px; border-bottom: 1px solid var(--border-color); position: sticky; top: 0; z-index: 100; box-shadow: 0 1px 3px rgba(0,0,0,0.05); }
        .nav-brand { display: flex; align-items: center; gap: 12px; font-size: 1.5rem; font-weight: 800; color: var(--text-dark); width: 250px; }
        .brand-icon { background: var(--primary); color: white; width: 36px; height: 36px; display: flex; align-items: center; justify-content: center; border-radius: 8px; font-size: 1.2rem; }
        .nav-tabs { display: flex; gap: 2rem; height: 100%; align-items: center; justify-content: center; flex: 1; }
        .nav-tab { color: var(--text-muted); font-weight: 600; transition: color 0.2s; height: 100%; display: flex; align-items: center; border-bottom: 3px solid transparent; }
        .nav-tab:hover { color: var(--primary); }
        .nav-tab.active { color: var(--text-dark); border-bottom-color: var(--primary); }
        .nav-actions { width: 250px; display: flex; justify-content: flex-end; }
        .btn-outline { padding: 0.6rem 1.5rem; border-radius: 8px; font-weight: 600; border: 2px solid var(--primary); color: var(--primary); text-decoration: none; transition: 0.2s; }
        .btn-outline:hover { background: var(--primary); color: white; }
        
        /* THE MAGIC FLOATING OFFER TICKER */
        .ticker-wrap {
            background: #1e293b; 
            color: white;
            padding: 12px 0;
            overflow: hidden;
            white-space: nowrap;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            position: relative;
        }
        .ticker-move {
            display: inline-block;
            white-space: nowrap;
            padding-left: 100%; 
            animation: ticker 25s linear infinite;
        }
        .ticker-item {
            display: inline-block;
            font-size: 1.1rem;
            font-weight: 500;
            padding: 0 3rem;
            border-right: 2px solid #334155;
        }
        .ticker-item:last-child { border-right: none; }
        .offer-shop { color: #facc15; font-weight: 800; margin-right: 5px; }
        .offer-location { color: #94a3b8; font-size: 0.9rem; margin-right: 10px; }
        
        @keyframes ticker {
            0% { transform: translateX(0); }
            100% { transform: translateX(-100%); }
        }

        .container { max-width: 1200px; margin: 3rem auto; padding: 0 1.5rem; }
        .page-header { text-align: center; margin-bottom: 3rem; }
        .page-header h2 { font-size: 2.2rem; font-weight: 800; margin-bottom: 0.5rem; }
        .dashboard-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 2rem; }
        .card { background: var(--card-bg); padding: 2.5rem 2rem; border-radius: 16px; border: 1px solid var(--border-color); box-shadow: 0 4px 6px rgba(0,0,0,0.05); transition: 0.3s; display: flex; flex-direction: column; text-align: center; align-items: center; text-decoration: none; color: inherit; }
        .card:hover { transform: translateY(-8px); box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1); border-color: #cbd5e1; }
        .card-icon { width: 60px; height: 60px; background: #eff6ff; color: var(--primary); border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 1.8rem; margin-bottom: 1.5rem; }
        .card h3 { font-size: 1.4rem; font-weight: 700; margin-bottom: 0.75rem; color: var(--text-dark); }
        .card p { color: var(--text-muted); font-size: 1rem; }
    </style>
</head>
<body>
    <nav class="top-nav">
        <div class="nav-tabs" style="justify-content: flex-start; flex: 0;">
            <a href="${pageContext.request.contextPath}/customer/dashboard" class="nav-tab active">Home</a>
            <a href="${pageContext.request.contextPath}/customer/shops" class="nav-tab">Store Directory</a>
        </div>
        <div style="display:flex; align-items:center; gap:2rem; justify-content: flex-end; flex: 1;">
            <div class="nav-brand" style="justify-content: flex-end; width: auto;">
                Crystal Plaza
                <div class="brand-icon" style="margin-left: 10px;">CP</div>
            </div>
            <a href="${pageContext.request.contextPath}/auth/login.jsp" class="btn-outline">Staff Portal</a>
        </div>
    </nav>

    <div class="ticker-wrap">
        <div class="ticker-move">
            <c:choose>
                <c:when test="${not empty offers}">
                    <c:forEach var="offer" items="${offers}">
                        <div class='ticker-item'><i class='fa-solid fa-tags' style='color:#facc15; margin-right:8px;'></i>
                        <span class='offer-shop'>${offer.shop.shopName}</span>
                        <span class='offer-location'>(Floor ${offer.shop.floorNumber}):</span>
                        ${offer.offerText}</div>
                    </c:forEach>
                </c:when>
                <c:otherwise>
                    <div class='ticker-item'>Welcome to Crystal Plaza. Neo-Genesis Galleria! Premium shopping, dining, and entertainment.</div>
                </c:otherwise>
            </c:choose>
        </div>
    </div>

    <div class="container">
        <div class="page-header">
            <h2>Welcome to Crystal Plaza! 👋</h2>
            <p style="color: var(--text-muted);">Explore top stores, navigate easily, and catch the best live deals in the ticker above!</p>
        </div>
        
        <div class="dashboard-grid">
            <a href="${pageContext.request.contextPath}/customer/shops" class="card">
                <div class="card-icon"><i class="fa-solid fa-store"></i></div>
                <h3>Shop Directory</h3>
                <p>Find your favorite brands, locate floors, and explore categories easily.</p>
            </a>
        </div>
    </div>
</body>
</html>
