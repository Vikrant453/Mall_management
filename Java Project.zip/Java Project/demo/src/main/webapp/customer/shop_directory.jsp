<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html>
<head>
    <title>Shop Directory | Crystal Plaza</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
        :root { --primary: #2563eb; --bg-main: #f0f9ff; --card-bg: #ffffff; --text-dark: #0f172a; --text-muted: #475569; --border-color: #e2e8f0; }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Inter', sans-serif; }
        body { background-color: var(--bg-main); color: var(--text-dark); line-height: 1.6; }
        .top-nav { background: var(--card-bg); padding: 0 3rem; display: flex; justify-content: space-between; align-items: center; height: 80px; border-bottom: 1px solid var(--border-color); position: sticky; top: 0; z-index: 100; box-shadow: 0 1px 3px rgba(0,0,0,0.05); }
        .nav-brand { display: flex; align-items: center; gap: 12px; font-size: 1.5rem; font-weight: 800; color: var(--text-dark); width: 250px; }
        .brand-icon { background: var(--primary); color: white; width: 36px; height: 36px; display: flex; align-items: center; justify-content: center; border-radius: 8px; font-size: 1.2rem; }
        .nav-tabs { display: flex; gap: 2rem; height: 100%; align-items: center; justify-content: center; flex: 1; }
        .nav-tab { color: var(--text-muted); font-weight: 600; transition: color 0.2s; height: 100%; display: flex; align-items: center; border-bottom: 3px solid transparent; text-decoration: none; }
        .nav-tab:hover { color: var(--primary); }
        .nav-tab.active { color: var(--text-dark); border-bottom-color: var(--primary); }
        .nav-actions { width: 250px; display: flex; justify-content: flex-end; }
        .btn-outline { padding: 0.6rem 1.5rem; border-radius: 8px; font-weight: 600; border: 2px solid var(--primary); color: var(--primary); text-decoration: none; transition: 0.2s; }
        .btn-outline:hover { background: var(--primary); color: white; }
        .container { max-width: 1200px; margin: 3rem auto; padding: 0 1.5rem; }
        h2 { font-weight: 800; margin-bottom: 1.5rem; font-size: 2rem; }
        .filters { display: flex; gap: 1rem; margin-bottom: 2rem; }
        .filter-btn { padding: 0.5rem 1.2rem; background: var(--card-bg); border: 1px solid var(--border-color); border-radius: 8px; cursor: pointer; font-weight: 600; color: var(--text-muted); transition: 0.2s; }
        .filter-btn.active { background: var(--primary); color: white; border-color: var(--primary); }
        .shop-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 1.5rem; }
        .shop-card { background: var(--card-bg); padding: 2rem; border-radius: 16px; border: 1px solid var(--border-color); box-shadow: 0 4px 6px rgba(0,0,0,0.05); transition: 0.3s; }
        .shop-card:hover { transform: translateY(-5px); box-shadow: 0 15px 20px -5px rgba(0,0,0,0.1); }
        .shop-name { font-size: 1.3rem; font-weight: 700; margin-bottom: 0.5rem; }
        .shop-meta { display: flex; justify-content: space-between; color: var(--text-muted); font-size: 0.9rem; margin-bottom: 1rem; }
        .badge { background: #eff6ff; color: var(--primary); padding: 0.25rem 0.75rem; border-radius: 999px; font-size: 0.85rem; font-weight: 600; display: inline-block; }
    </style>
</head>
<body>
    <nav class="top-nav">
        <div class="nav-brand"><div class="brand-icon">CP</div> Crystal Plaza</div>
        <div class="nav-tabs">
            <a href="${pageContext.request.contextPath}/customer/dashboard" class="nav-tab">Home</a>
            <a href="${pageContext.request.contextPath}/customer/shops" class="nav-tab active">Store Directory</a>
        </div>
        <div class="nav-actions"><a href="${pageContext.request.contextPath}/auth/login.jsp" class="btn-outline">Staff Portal</a></div>
    </nav>
    <div class="container">
        <h2><i class="fa-solid fa-store"></i> Store Directory</h2>
        
        <div class="filters">
            <button class="filter-btn active" onclick="filterShops('All')">All</button>
            <button class="filter-btn" onclick="filterShops('Fashion')">Fashion</button>
            <button class="filter-btn" onclick="filterShops('Food')">Food & Dining</button>
            <button class="filter-btn" onclick="filterShops('Electronics')">Electronics</button>
            <button class="filter-btn" onclick="filterShops('Entertainment')">Entertainment</button>
            <button class="filter-btn" onclick="filterShops('Services')">Services</button>
        </div>

        <c:if test="${not empty param.success}">
            <div style="background: #d1fae5; color: #065f46; padding: 1rem; border-radius: 8px; margin-bottom: 2rem; font-weight: 600;"><i class="fa-solid fa-check-circle"></i> ${param.success}</div>
        </c:if>

        <div class="shop-grid" id="shopGrid">
            <c:forEach var="shop" items="${shops}">
                <c:if test="${shop.status eq 'active'}">
                    <div class="shop-card" data-category="${shop.category}">
                        <div class="shop-name">${shop.shopName}</div>
                        <div class="shop-meta" style="flex-direction: column; gap: 0.25rem;">
                            <span><i class="fa-solid fa-layer-group"></i> Floor ${shop.floorNumber} | <i class="fa-solid fa-door-open"></i> No. ${shop.shopNumber}</span>
                            <span><i class="fa-solid fa-user-tie"></i> Owner: ${shop.owner.username}</span>
                        </div>
                        <div class="badge">${shop.category}</div>
                        
                        <c:if test="${not empty shop.offer}">
                            <div style="margin-top: 1rem; padding: 0.75rem; background: #fefce8; border: 1px dashed #facc15; border-radius: 8px; font-size: 0.9rem; color: #b45309; font-weight: 600;">
                                <i class="fa-solid fa-tag"></i> Offer: ${shop.offer.offerText}
                            </div>
                        </c:if>
                        
                        <div style="margin-top: 1.5rem; border-top: 1px solid var(--border-color); padding-top: 1.5rem;">
                            <h4 style="font-size: 0.9rem; margin-bottom: 0.5rem; color: var(--text-dark);"><i class="fa-solid fa-comment-dots"></i> Leave Review / Complaint</h4>
                            <form action="${pageContext.request.contextPath}/customer/complaint/add" method="post">
                                <input type="hidden" name="shopId" value="${shop.id}">
                                <input type="text" name="customerName" required placeholder="Your Name" style="width: 100%; padding: 0.5rem; border: 1px solid var(--border-color); border-radius: 6px; margin-bottom: 0.5rem; font-family: 'Inter', sans-serif;">
                                <textarea name="content" required placeholder="Write your review or complaint..." rows="2" style="width: 100%; padding: 0.5rem; border: 1px solid var(--border-color); border-radius: 6px; margin-bottom: 0.5rem; font-family: 'Inter', sans-serif; resize: vertical;"></textarea>
                                <button type="submit" style="width: 100%; padding: 0.5rem; background: white; border: 1px solid var(--primary); color: var(--primary); border-radius: 6px; cursor: pointer; font-weight: 600; transition: 0.2s;" onmouseover="this.style.background='var(--primary)'; this.style.color='white';" onmouseout="this.style.background='white'; this.style.color='var(--primary)';">Submit</button>
                            </form>
                        </div>
                    </div>
                </c:if>
            </c:forEach>
        </div>
        
        <c:if test="${empty shops}">
            <div style="text-align:center; padding: 3rem; color: var(--text-muted);">
                <i class="fa-solid fa-shop-slash" style="font-size: 3rem; margin-bottom: 1rem;"></i>
                <p>No stores available currently.</p>
            </div>
        </c:if>
    </div>

    <script>
        function filterShops(category) {
            document.querySelectorAll('.filter-btn').forEach(btn => btn.classList.remove('active'));
            event.target.classList.add('active');
            
            const cards = document.querySelectorAll('.shop-card');
            cards.forEach(card => {
                if (category === 'All' || card.dataset.category.includes(category)) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            });
        }
    </script>
</body>
</html>
