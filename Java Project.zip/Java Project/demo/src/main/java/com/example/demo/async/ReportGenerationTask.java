package com.example.demo.async;

import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
public class ReportGenerationTask {

    @Async
    public void generateFinancialReport() {
        try {
            System.out.println("Starting complex financial report generation on thread: " + Thread.currentThread().getName());
            // Simulate long running task
            Thread.sleep(5000); 
            System.out.println("Financial report generated successfully!");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
