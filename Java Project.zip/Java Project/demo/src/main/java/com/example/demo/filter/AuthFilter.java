package com.example.demo.filter;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import org.springframework.stereotype.Component;
import java.io.IOException;

@Component
public class AuthFilter implements Filter {

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;
        HttpSession session = req.getSession(false);
        String uri = req.getRequestURI();

        boolean isPublic = uri.contains("/auth/") || uri.endsWith("/login") 
            || uri.endsWith("/logout") || uri.startsWith("/customer") 
            || uri.contains("/css") || uri.contains("/js") || uri.equals("/")
            || uri.contains("/includes/") || uri.contains("/favicon");

        if (isPublic) { chain.doFilter(request, response); return; }

        if (session == null || session.getAttribute("role") == null) {
            res.sendRedirect(req.getContextPath() + "/auth/login.jsp");
            return;
        }

        String role = (String) session.getAttribute("role");
        if (uri.startsWith(req.getContextPath() + "/admin") && !"admin".equals(role)) {
            res.sendRedirect(req.getContextPath() + "/auth/login.jsp?error=unauthorized");
            return;
        }
        if (uri.startsWith(req.getContextPath() + "/owner") && !"owner".equals(role)) {
            res.sendRedirect(req.getContextPath() + "/auth/login.jsp?error=unauthorized");
            return;
        }

        chain.doFilter(request, response);
    }
}
