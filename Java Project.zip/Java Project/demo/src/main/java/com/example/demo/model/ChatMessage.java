package com.example.demo.model;

public class ChatMessage {
    private Long messageId;
    private String sender;
    private String content;
    private String timestamp;
    private String type;
    private String role;

    public ChatMessage() {}

    public ChatMessage(String sender, String content, String timestamp, String type, String role) {
        this.sender = sender;
        this.content = content;
        this.timestamp = timestamp;
        this.type = type;
        this.role = role;
    }

    public Long getMessageId() { return messageId; }
    public void setMessageId(Long messageId) { this.messageId = messageId; }
    public String getSender() { return sender; }
    public void setSender(String sender) { this.sender = sender; }
    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }
    public String getTimestamp() { return timestamp; }
    public void setTimestamp(String timestamp) { this.timestamp = timestamp; }
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }
}
