package com.example.demo.service;

import com.example.demo.entity.*;
import com.example.demo.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class MallService {

    @Autowired private UserRepository userRepo;
    @Autowired private ShopRepository shopRepo;
    @Autowired private BillRepository billRepo;
    @Autowired private OfferRepository offerRepo;
    @Autowired private BillItemRepository billItemRepo;

    // ---- AUTH ----
    public User authenticate(String username, String password) {
        return userRepo.findByUsername(username)
            .filter(u -> u.getPassword().equals(password))
            .orElse(null);
    }

    // ---- ADMIN STATS ----
    public long getActiveShopsCount() { return shopRepo.count(); }
    public long getRegisteredOwnersCount() { return userRepo.countByRole("owner"); }
    public Double getGrossRevenue() {
        Double sum = billRepo.sumTotalAmount();
        return sum != null ? sum : 0.0;
    }
    public long getTotalBillsCount() { return billRepo.count(); }

    // ---- SHOPS ----
    public List<Shop> getAllShops() { return shopRepo.findAll(); }
    public Optional<Shop> getShopById(Long id) { return shopRepo.findById(id); }
    public Shop saveShop(Shop shop) { return shopRepo.save(shop); }
    public void deleteShop(Long id) { shopRepo.deleteById(id); }
    public List<Shop> getShopsByOwner(String ownerUsername) { return shopRepo.findByOwnerUsername(ownerUsername); }

    // ---- USERS/OWNERS ----
    public List<User> getAllOwners() { return userRepo.findByRole("owner"); }
    public List<User> getAllUsers() { return userRepo.findAll(); }
    public User saveUser(User user) { return userRepo.save(user); }
    public void deleteUser(String username) { userRepo.deleteByUsername(username); }
    public Optional<User> getUserById(String username) { return userRepo.findByUsername(username); }

    // ---- BILLS ----
    public List<Bill> getAllBills() { return billRepo.findAllOrderByDateDesc(); }
    public List<Bill> getBillsByShop(Long shopId) { return billRepo.findByShopId(shopId); }
    public Bill saveBill(Bill bill) { return billRepo.save(bill); }
    public Optional<Bill> getBillById(Long id) { return billRepo.findById(id); }

    // ---- OFFERS ----
    public List<Offer> getAllOffers() { return offerRepo.findAll(); }
    public Optional<Offer> getOfferByShop(Long shopId) { return offerRepo.findByShopId(shopId); }
    public void saveOffer(Offer offer) { offerRepo.save(offer); }
    public void deleteOfferByShop(Long shopId) { offerRepo.deleteByShopId(shopId); }

    // ---- INVENTORY ----
    @Autowired private InventoryRepository inventoryRepo;
    public List<InventoryItem> getInventoryByShop(Long shopId) { return inventoryRepo.findByShopId(shopId); }
    public InventoryItem saveInventoryItem(InventoryItem item) { return inventoryRepo.save(item); }
    public void deleteInventoryItem(Long id) { inventoryRepo.deleteById(id); }

    // ---- EMPLOYEES ----
    @Autowired private EmployeeRepository employeeRepo;
    public List<Employee> getEmployeesByShop(Long shopId) { return employeeRepo.findByShopId(shopId); }
    public Employee saveEmployee(Employee employee) { return employeeRepo.save(employee); }
    public void deleteEmployee(Long id) { employeeRepo.deleteById(id); }
}
