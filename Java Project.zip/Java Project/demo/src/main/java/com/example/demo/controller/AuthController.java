package com.example.demo.controller;

import com.example.demo.entity.User;
import com.example.demo.service.MallService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
public class AuthController {

    @Autowired private MallService mallService;

    @GetMapping("/")
    public String home() { return "redirect:/customer/dashboard"; }

    @GetMapping("/auth/login.jsp")
    public String loginPage() { return "auth/login"; }

    @GetMapping("/login")
    public String loginRedirect() { return "redirect:/auth/login.jsp"; }

    @PostMapping("/login")
    public String doLogin(@RequestParam String username,
                          @RequestParam String password,
                          HttpSession session) {
        User user = mallService.authenticate(username, password);
        if (user == null) {
            session.setAttribute("loginError", "Invalid username or password.");
            return "redirect:/auth/login.jsp?error=1";
        }
        session.setAttribute("userId", user.getUsername());
        session.setAttribute("username", user.getUsername());
        session.setAttribute("role", user.getRole());
        return switch (user.getRole()) {
            case "admin" -> "redirect:/admin/dashboard";
            case "owner" -> "redirect:/owner/dashboard";
            default -> "redirect:/customer/dashboard";
        };
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/auth/login.jsp";
    }
}
