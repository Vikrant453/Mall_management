package com.example.demo.controller;

import com.example.demo.service.MallService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/customer")
public class CustomerController {

    @Autowired private MallService mallService;

    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        model.addAttribute("offers", mallService.getAllOffers());
        return "customer/customer_dashboard";
    }

    @GetMapping("/shops")
    public String shopDirectory(Model model) {
        model.addAttribute("shops", mallService.getAllShops());
        return "customer/shop_directory";
    }

    @Autowired private com.example.demo.repository.ComplaintRepository complaintRepo;

    @PostMapping("/complaint/add")
    public String addComplaint(@RequestParam Long shopId, @RequestParam String customerName, @RequestParam String content) {
        com.example.demo.entity.Complaint complaint = new com.example.demo.entity.Complaint();
        complaint.setCustomerName(customerName);
        complaint.setContent(content);
        mallService.getShopById(shopId).ifPresent(complaint::setShop);
        complaintRepo.save(complaint);
        return "redirect:/customer/shops?success=Review+submitted";
    }
}
