package com.example.demo;

import com.example.demo.entity.User;
import com.example.demo.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.EnableAsync;

@SpringBootApplication
@EnableAsync
public class DemoApplication extends SpringBootServletInitializer {
    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        return application.sources(DemoApplication.class);
    }
    public static void main(String[] args) {
        try {
            // Automatically patch the user's existing database before Hibernate starts!
            java.sql.Connection conn = java.sql.DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/mall_management?useSSL=false&allowPublicKeyRetrieval=true", "root", "root");
            java.sql.Statement stmt = conn.createStatement();
            try { stmt.execute("ALTER TABLE users ADD COLUMN id BIGINT AUTO_INCREMENT PRIMARY KEY FIRST;"); } catch(Exception e) {}
            try { stmt.execute("ALTER TABLE offers ADD COLUMN id BIGINT AUTO_INCREMENT PRIMARY KEY FIRST;"); } catch(Exception e) {}
            stmt.close(); conn.close();
        } catch(Exception e) {
            e.printStackTrace();
        }
        SpringApplication.run(DemoApplication.class, args);
    }

}
