package com.example.demo.service;

import com.example.demo.entity.Bill;
import com.example.demo.entity.BillItem;
import com.lowagie.text.*;
import com.lowagie.text.pdf.*;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.text.DecimalFormat;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Service
public class PdfService {
    private static final DecimalFormat MONEY = new DecimalFormat("0.00");
    private static final String DASH_LINE = "------------------------------------";
    private static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("d/M/yyyy");

    // =====================================================================
    //  RECEIPT-STYLE INVOICE  (matches the printout sample)
    // =====================================================================
    public byte[] generateInvoicePdf(Bill bill) {
        ByteArrayOutputStream out = new ByteArrayOutputStream();

        // Narrow receipt page: 226 pt wide (~8 cm), tall enough for content
        Rectangle pageSize = new Rectangle(226, 600);
        Document document = new Document(pageSize, 10, 10, 14, 14);
        PdfWriter.getInstance(document, out);
        document.open();

        Font shopFont  = FontFactory.getFont(FontFactory.COURIER_BOLD,  14);
        Font subFont   = FontFactory.getFont(FontFactory.COURIER,        8);
        Font boldFont  = FontFactory.getFont(FontFactory.COURIER_BOLD,   9);
        Font normFont  = FontFactory.getFont(FontFactory.COURIER,        9);
        Font totalFont = FontFactory.getFont(FontFactory.COURIER_BOLD,  11);

        // ---- Shop name ----
        String shopName = (bill.getShop() != null && bill.getShop().getShopName() != null)
                ? bill.getShop().getShopName().toUpperCase()
                : "SHOP";
        Paragraph pShop = new Paragraph(shopName, shopFont);
        pShop.setAlignment(Element.ALIGN_CENTER);
        document.add(pShop);

        // ---- Sub-header ----
        Paragraph pSub = new Paragraph("TAX INVOICE / CASH MEMO", subFont);
        pSub.setAlignment(Element.ALIGN_CENTER);
        document.add(pSub);

        document.add(new Paragraph(DASH_LINE, normFont));

        // ---- Customer info ----
        document.add(new Paragraph("Customer: " + safe(bill.getCustomerName()), normFont));
        document.add(new Paragraph("Contact:  " + safe(bill.getCustomerPhone()), normFont));
        String dateStr = (bill.getBillDate() != null) ? bill.getBillDate().format(DATE_FMT) : "-";
        document.add(new Paragraph("Date:     " + dateStr, normFont));

        document.add(new Paragraph(DASH_LINE, normFont));

        // ---- Items table ----
        PdfPTable table = new PdfPTable(new float[]{4.5f, 1.5f, 2.5f});
        table.setWidthPercentage(100);
        table.setSpacingBefore(2);

        // Header row
        table.addCell(receiptCell("ITEM",   boldFont, Element.ALIGN_LEFT,   false));
        table.addCell(receiptCell("QTY",    boldFont, Element.ALIGN_CENTER, false));
        table.addCell(receiptCell("AMOUNT", boldFont, Element.ALIGN_RIGHT,  false));

        // Dash row
        table.addCell(receiptFullSpanDash(DASH_LINE, normFont));

        int totalItems = 0;
        if (bill.getItems() != null) {
            for (BillItem item : bill.getItems()) {
                int qty = item.getQuantity() != null ? item.getQuantity() : 0;
                double sub = n(item.getSubtotal());
                table.addCell(receiptCell(safe(item.getItemName()),     normFont, Element.ALIGN_LEFT,   false));
                table.addCell(receiptCell(String.valueOf(qty),          normFont, Element.ALIGN_CENTER, false));
                table.addCell(receiptCell(MONEY.format(sub),            normFont, Element.ALIGN_RIGHT,  false));
                totalItems += qty;
            }
        }

        // Dash row
        table.addCell(receiptFullSpanDash(DASH_LINE, normFont));

        // Total items row
        table.addCell(receiptCell("TOTAL ITEMS:",                        boldFont, Element.ALIGN_LEFT,   false));
        table.addCell(receiptCell(String.valueOf(totalItems),            boldFont, Element.ALIGN_CENTER, false));
        table.addCell(receiptCell("",                                    normFont, Element.ALIGN_RIGHT,  false));

        document.add(table);

        // ---- Discount (if any) ----
        double subtotal = n(bill.getTotalAmount());
        double grand    = n(bill.getFinalAmount() != null ? bill.getFinalAmount() : bill.getTotalAmount());

        if (bill.getDiscountPercentage() != null && bill.getDiscountPercentage() > 0) {
            Paragraph disc = new Paragraph(
                    "Discount (" + bill.getDiscountPercentage().intValue() + "%): -Rs." + MONEY.format(subtotal - grand),
                    normFont);
            disc.setAlignment(Element.ALIGN_RIGHT);
            document.add(disc);
        }

        // ---- Grand total ----
        Paragraph pGrand = new Paragraph("GRAND TOTAL:    Rs." + MONEY.format(grand), totalFont);
        pGrand.setAlignment(Element.ALIGN_LEFT);
        pGrand.setSpacingBefore(4);
        document.add(pGrand);

        // ---- Footer ----
        document.add(new Paragraph(DASH_LINE, normFont));
        Paragraph thanks = new Paragraph("Thank You! Please Visit Again.", subFont);
        thanks.setAlignment(Element.ALIGN_CENTER);
        thanks.setSpacingBefore(4);
        document.add(thanks);

        document.close();
        return out.toByteArray();
    }

    // =====================================================================
    //  Helper: single cell for receipt table (no border)
    // =====================================================================
    private PdfPCell receiptCell(String text, Font font, int align, boolean border) {
        PdfPCell cell = new PdfPCell(new Phrase(text, font));
        cell.setHorizontalAlignment(align);
        cell.setBorder(border ? Rectangle.BOX : Rectangle.NO_BORDER);
        cell.setPaddingTop(2);
        cell.setPaddingBottom(2);
        return cell;
    }

    // A full-width dashed line spanning all 3 columns
    private PdfPCell receiptFullSpanDash(String dash, Font font) {
        PdfPCell cell = new PdfPCell(new Phrase(dash, font));
        cell.setColspan(3);
        cell.setBorder(Rectangle.NO_BORDER);
        cell.setPaddingTop(1);
        cell.setPaddingBottom(1);
        return cell;
    }

    // =====================================================================
    //  FINANCIAL REPORT PDF  (unchanged from original)
    // =====================================================================
    public byte[] generateFinancialReportPdf(List<Bill> bills, double totalRevenue, long totalBills, long totalShops) {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        Document document = new Document();
        PdfWriter.getInstance(document, out);
        document.open();

        Font title  = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 18);
        Font h      = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 12);
        Font normal = FontFactory.getFont(FontFactory.HELVETICA,      10);

        Paragraph header = new Paragraph("Crystal Plaza - Financial Report", title);
        header.setAlignment(Element.ALIGN_CENTER);
        document.add(header);
        document.add(new Paragraph(" "));

        document.add(new Paragraph("Total Gross Revenue: Rs." + MONEY.format(totalRevenue), h));
        document.add(new Paragraph("Total Bills: " + totalBills, normal));
        document.add(new Paragraph("Total Shops: " + totalShops, normal));
        document.add(new Paragraph(" "));

        PdfPTable table = new PdfPTable(new float[]{1.2f, 2.3f, 2.5f, 2.0f, 2.2f, 1.5f});
        table.setWidthPercentage(100);
        table.addCell(th("Bill ID"));
        table.addCell(th("Date"));
        table.addCell(th("Customer"));
        table.addCell(th("Phone"));
        table.addCell(th("Shop"));
        table.addCell(th("Amount"));

        if (bills != null) {
            for (Bill b : bills) {
                table.addCell(td("#" + b.getId()));
                table.addCell(td(b.getBillDate() != null ? String.valueOf(b.getBillDate()) : ""));
                table.addCell(td(safe(b.getCustomerName())));
                table.addCell(td(safe(b.getCustomerPhone())));
                table.addCell(td(b.getShop() != null ? safe(b.getShop().getShopName()) : ""));
                table.addCell(td("Rs." + MONEY.format(n(b.getTotalAmount()))));
            }
        }
        document.add(table);
        document.close();
        return out.toByteArray();
    }

    // =====================================================================
    //  OWNER SHOP REPORT PDF  (unchanged from original)
    // =====================================================================
    public byte[] generateOwnerShopReportPdf(String shopName, List<Bill> bills, double revenue) {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        Document document = new Document();
        PdfWriter.getInstance(document, out);
        document.open();

        Font title  = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 18);
        Font h      = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 12);
        Font normal = FontFactory.getFont(FontFactory.HELVETICA,      10);

        Paragraph header = new Paragraph("Crystal Plaza - Shop Report", title);
        header.setAlignment(Element.ALIGN_CENTER);
        document.add(header);
        document.add(new Paragraph(" "));

        document.add(new Paragraph("Shop: " + safe(shopName), h));
        document.add(new Paragraph("Total Revenue: Rs." + MONEY.format(revenue), h));
        document.add(new Paragraph("Total Bills: " + (bills != null ? bills.size() : 0), normal));
        document.add(new Paragraph(" "));

        PdfPTable table = new PdfPTable(new float[]{1.2f, 2.5f, 2.5f, 2.0f, 1.6f});
        table.setWidthPercentage(100);
        table.addCell(th("Bill ID"));
        table.addCell(th("Date"));
        table.addCell(th("Customer"));
        table.addCell(th("Phone"));
        table.addCell(th("Amount"));

        if (bills != null) {
            for (Bill b : bills) {
                table.addCell(td("#" + b.getId()));
                table.addCell(td(b.getBillDate() != null ? String.valueOf(b.getBillDate()) : ""));
                table.addCell(td(safe(b.getCustomerName())));
                table.addCell(td(safe(b.getCustomerPhone())));
                table.addCell(td("Rs." + MONEY.format(n(b.getTotalAmount()))));
            }
        }
        document.add(table);
        document.close();
        return out.toByteArray();
    }

    // =====================================================================
    //  Shared helpers
    // =====================================================================
    private static PdfPCell th(String text) {
        Font f = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 10);
        PdfPCell c = new PdfPCell(new Phrase(text, f));
        c.setPadding(6);
        return c;
    }

    private static PdfPCell td(String text) {
        Font f = FontFactory.getFont(FontFactory.HELVETICA, 10);
        PdfPCell c = new PdfPCell(new Phrase(text, f));
        c.setPadding(6);
        return c;
    }

    private static String safe(String s) { return s == null ? "" : s; }
    private static double n(Double d)    { return d == null ? 0.0 : d; }
}