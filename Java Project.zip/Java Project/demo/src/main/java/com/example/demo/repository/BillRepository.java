package com.example.demo.repository;

import com.example.demo.entity.Bill;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.util.List;

public interface BillRepository extends JpaRepository<Bill, Long> {
    @Query("SELECT SUM(b.totalAmount) FROM Bill b")
    Double sumTotalAmount();
    List<Bill> findByShopId(Long shopId);
    @Query("SELECT b FROM Bill b ORDER BY b.billDate DESC")
    List<Bill> findAllOrderByDateDesc();
}
