package com.example.demo.controller;

import com.example.demo.entity.*;
import com.example.demo.service.MallService;
import com.example.demo.async.ReportGenerationTask;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/admin")
public class AdminController {

    @Autowired private MallService mallService;
    @Autowired private ReportGenerationTask reportTask;

    private boolean isAdmin(HttpSession session) {
        return "admin".equals(session.getAttribute("role"));
    }

    @GetMapping("/dashboard")
    public String dashboard(Model model, HttpSession session) {
        if (!isAdmin(session)) return "redirect:/auth/login.jsp";
        model.addAttribute("activeShops", mallService.getActiveShopsCount());
        model.addAttribute("registeredOwners", mallService.getRegisteredOwnersCount());
        model.addAttribute("grossRevenue", mallService.getGrossRevenue());
        model.addAttribute("totalBills", mallService.getTotalBillsCount());
        return "admin/admin_dashboard";
    }

    @GetMapping("/manage-shops")
    public String manageShops(Model model, HttpSession session) {
        if (!isAdmin(session)) return "redirect:/auth/login.jsp";
        model.addAttribute("shops", mallService.getAllShops());
        model.addAttribute("owners", mallService.getAllOwners());
        return "admin/manage_shops";
    }

    @PostMapping("/shop/add")
    public String addShop(@RequestParam String shopName, @RequestParam String category,
                          @RequestParam Integer floorNumber, @RequestParam String ownerUsername, 
                          HttpSession session) {
        if (!isAdmin(session)) return "redirect:/auth/login.jsp";
        Shop shop = new Shop();
        shop.setShopName(shopName); shop.setCategory(category);
        shop.setFloorNumber(floorNumber);
        shop.setStatus("Open");
        mallService.getUserById(ownerUsername).ifPresent(shop::setOwner);
        mallService.saveShop(shop);
        return "redirect:/admin/manage-shops?success=Shop+added";
    }

    @PostMapping("/shop/delete/{id}")
    public String deleteShop(@PathVariable Long id, HttpSession session) {
        if (!isAdmin(session)) return "redirect:/auth/login.jsp";
        mallService.deleteShop(id);
        return "redirect:/admin/manage-shops?success=Shop+deleted";
    }

    @GetMapping("/manage-owners")
    public String manageOwners(Model model, HttpSession session) {
        if (!isAdmin(session)) return "redirect:/auth/login.jsp";
        model.addAttribute("owners", mallService.getAllOwners());
        return "admin/manage_owners";
    }

    @PostMapping("/owner/add")
    public String addOwner(@RequestParam String username, @RequestParam String password,
                           @RequestParam(required = false) String phone, HttpSession session) {
        if (!isAdmin(session)) return "redirect:/auth/login.jsp";
        User user = new User();
        user.setUsername(username); user.setPassword(password);
        user.setRole("owner");
        user.setPhone(phone);
        mallService.saveUser(user);
        return "redirect:/admin/manage-owners?success=Owner+added";
    }

    @PostMapping("/owner/delete/{username}")
    public String deleteOwner(@PathVariable String username, HttpSession session) {
        if (!isAdmin(session)) return "redirect:/auth/login.jsp";
        mallService.deleteUser(username);
        return "redirect:/admin/manage-owners?success=Owner+deleted";
    }

    @GetMapping("/reports")
    public String reports(Model model, HttpSession session) {
        if (!isAdmin(session)) return "redirect:/auth/login.jsp";
        
        java.util.Map<String, Double> shopRevenues = new java.util.HashMap<>();
        for (Bill bill : mallService.getAllBills()) {
            String shopName = bill.getShop().getShopName();
            shopRevenues.put(shopName, shopRevenues.getOrDefault(shopName, 0.0) + (bill.getTotalAmount() != null ? bill.getTotalAmount() : 0.0));
        }
        
        model.addAttribute("bills", mallService.getAllBills());
        model.addAttribute("totalRevenue", mallService.getGrossRevenue());
        model.addAttribute("totalBills", mallService.getTotalBillsCount());
        model.addAttribute("totalShops", mallService.getActiveShopsCount());
        model.addAttribute("shopRevenues", shopRevenues);
        return "admin/mall_reports";
    }

    @Autowired private com.example.demo.repository.NotificationRepository notificationRepo;
    @Autowired private com.example.demo.repository.GlobalMessageRepository globalMessageRepository;

    @GetMapping("/messenger")
    public String messenger(Model model, HttpSession session) {
        if (!isAdmin(session)) return "redirect:/auth/login.jsp";
        model.addAttribute("username", session.getAttribute("username"));
        model.addAttribute("role", "admin");
        model.addAttribute("notifications", notificationRepo.findAllOrderByIdDesc());
        model.addAttribute("messages", globalMessageRepository.findAll());
        return "admin/messenger";
    }

    @PostMapping("/notification/delete/{id}")
    public String deleteNotification(@PathVariable Long id, HttpSession session) {
        if (!isAdmin(session)) return "redirect:/auth/login.jsp";
        notificationRepo.deleteById(id);
        return "redirect:/admin/messenger?success=Notification+deleted";
    }

    @PostMapping("/reports/generate-async")
    public String generateReport(HttpSession session) {
        if (!isAdmin(session)) return "redirect:/auth/login.jsp";
        reportTask.generateFinancialReport();
        return "redirect:/admin/reports?msg=Report+generation+started+in+background";
    }

    @PostMapping("/message/delete/{id}")
    public String deleteMessage(@PathVariable Long id, HttpSession session) {
        if (!isAdmin(session)) return "redirect:/auth/login.jsp";
        globalMessageRepository.deleteById(id);
        return "redirect:/admin/messenger?success=Message+deleted";
    }
}
