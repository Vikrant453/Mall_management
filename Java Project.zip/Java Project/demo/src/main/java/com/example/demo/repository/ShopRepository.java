package com.example.demo.repository;

import com.example.demo.entity.Shop;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ShopRepository extends JpaRepository<Shop, Long> {
    List<Shop> findByOwnerUsername(String ownerUsername);
    List<Shop> findByCategory(String category);
    List<Shop> findByFloorNumber(Integer floorNumber);
}
