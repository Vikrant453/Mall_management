package com.example.demo.controller;

import com.example.demo.entity.*;
import com.example.demo.service.MallService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/owner")
public class OwnerController {

    @Autowired private MallService mallService;

    private boolean isOwner(HttpSession session) {
        return "owner".equals(session.getAttribute("role"));
    }

    private String getOwnerUsername(HttpSession session) {
        return (String) session.getAttribute("username");
    }

    @GetMapping("/dashboard")
    public String dashboard(Model model, HttpSession session) {
        if (!isOwner(session)) return "redirect:/auth/login.jsp";
        String ownerId = getOwnerUsername(session);
        List<Shop> myShops = mallService.getShopsByOwner(ownerId);
        Shop myShop = myShops.isEmpty() ? null : myShops.get(0);
        model.addAttribute("myShop", myShop);
        if (myShop != null) {
            model.addAttribute("shopBills", mallService.getBillsByShop(myShop.getId()));
            model.addAttribute("myOffer", mallService.getOfferByShop(myShop.getId()).orElse(null));
            double shopRevenue = mallService.getBillsByShop(myShop.getId())
                .stream().mapToDouble(b -> b.getTotalAmount() != null ? b.getTotalAmount() : 0).sum();
            model.addAttribute("shopRevenue", shopRevenue);
            model.addAttribute("totalBills", mallService.getBillsByShop(myShop.getId()).size());
            
            // Inventory Low Stock Check
            List<InventoryItem> inventory = mallService.getInventoryByShop(myShop.getId());
            long lowStockCount = inventory.stream().filter(i -> i.getQuantity() != null && i.getQuantity() < 5).count();
            model.addAttribute("lowStockCount", lowStockCount);
            model.addAttribute("inventory", inventory);
        }
        return "owner/owner_dashboard";
    }

    @GetMapping("/inventory")
    public String inventory(Model model, HttpSession session) {
        if (!isOwner(session)) return "redirect:/auth/login.jsp";
        String ownerId = getOwnerUsername(session);
        List<Shop> myShops = mallService.getShopsByOwner(ownerId);
        if (!myShops.isEmpty()) {
            Shop shop = myShops.get(0);
            model.addAttribute("myShop", shop);
            model.addAttribute("inventory", mallService.getInventoryByShop(shop.getId()));
        }
        return "owner/inventory";
    }

    @PostMapping("/inventory/add")
    public String addInventory(@RequestParam Long shopId, @RequestParam String itemName,
                               @RequestParam Integer quantity, HttpSession session) {
        if (!isOwner(session)) return "redirect:/auth/login.jsp";
        InventoryItem item = new InventoryItem();
        item.setItemName(itemName);
        item.setQuantity(quantity);
        mallService.getShopById(shopId).ifPresent(item::setShop);
        mallService.saveInventoryItem(item);
        return "redirect:/owner/inventory?success=Item+added";
    }

    @PostMapping("/inventory/delete/{id}")
    public String deleteInventory(@PathVariable Long id, HttpSession session) {
        if (!isOwner(session)) return "redirect:/auth/login.jsp";
        mallService.deleteInventoryItem(id);
        return "redirect:/owner/inventory?success=Item+removed";
    }

    @GetMapping("/bills")
    public String bills(Model model, HttpSession session) {
        if (!isOwner(session)) return "redirect:/auth/login.jsp";
        String ownerId = getOwnerUsername(session);
        List<Shop> myShops = mallService.getShopsByOwner(ownerId);
        if (!myShops.isEmpty()) {
            model.addAttribute("bills", mallService.getBillsByShop(myShops.get(0).getId()));
            model.addAttribute("myShop", myShops.get(0));
        }
        return "owner/bill_generator";
    }

    @PostMapping("/bill/add")
    public String addBill(@RequestParam String customerName, @RequestParam String customerPhone,
                          @RequestParam Long shopId, @RequestParam Double totalAmount,
                          @RequestParam(required = false, defaultValue = "0") Double discountPercentage,
                          @RequestParam("itemName[]") List<String> itemNames,
                          @RequestParam("quantity[]") List<Integer> quantities,
                          @RequestParam("price[]") List<Double> prices,
                          HttpSession session) {
        if (!isOwner(session)) return "redirect:/auth/login.jsp";
        Bill bill = new Bill();
        bill.setCustomerName(customerName); bill.setCustomerPhone(customerPhone);
        
        // totalAmount from form is actually the final amount since JS updates it, but let's recalculate cleanly or just store both
        double subtotal = 0;
        java.util.List<BillItem> items = new java.util.ArrayList<>();
        for (int i = 0; i < itemNames.size(); i++) {
            BillItem item = new BillItem();
            item.setItemName(itemNames.get(i));
            item.setQuantity(quantities.get(i));
            item.setPrice(prices.get(i));
            double itemSub = quantities.get(i) * prices.get(i);
            item.setSubtotal(itemSub);
            item.setBill(bill);
            items.add(item);
            subtotal += itemSub;
        }
        
        bill.setTotalAmount(subtotal);
        bill.setDiscountPercentage(discountPercentage);
        bill.setFinalAmount(subtotal * (1 - (discountPercentage / 100)));
        bill.setStatus("paid");
        mallService.getShopById(shopId).ifPresent(bill::setShop);
        bill.setItems(items);
        
        Bill savedBill = mallService.saveBill(bill);
        return "redirect:/owner/bill/invoice/" + savedBill.getId();
    }

    @GetMapping("/bill/invoice/{id}")
    public String viewInvoice(@PathVariable Long id, Model model, HttpSession session) {
        if (!isOwner(session)) return "redirect:/auth/login.jsp";
        mallService.getBillById(id).ifPresent(bill -> model.addAttribute("bill", bill));
        return "owner/bill_invoice";
    }

    @PostMapping("/offer/save")
    public String saveOffer(@RequestParam Long shopId, @RequestParam String offerText,
                            @RequestParam(required = false) Integer discountPercent,
                            HttpSession session) {
        if (!isOwner(session)) return "redirect:/auth/login.jsp";
        mallService.deleteOfferByShop(shopId);
        Offer offer = new Offer();
        offer.setOfferText(offerText);
        offer.setDiscountPercent(discountPercent != null ? discountPercent : 0);
        mallService.getShopById(shopId).ifPresent(offer::setShop);
        mallService.saveOffer(offer);
        return "redirect:/owner/dashboard?success=Offer+updated";
    }

    @PostMapping("/offer/delete/{shopId}")
    public String deleteOffer(@PathVariable Long shopId, HttpSession session) {
        if (!isOwner(session)) return "redirect:/auth/login.jsp";
        mallService.deleteOfferByShop(shopId);
        return "redirect:/owner/dashboard?success=Offer+removed";
    }

    @GetMapping("/reports")
    public String reports(Model model, HttpSession session) {
        if (!isOwner(session)) return "redirect:/auth/login.jsp";
        String ownerId = getOwnerUsername(session);
        List<Shop> myShops = mallService.getShopsByOwner(ownerId);
        if (!myShops.isEmpty()) {
            Shop shop = myShops.get(0);
            List<Bill> bills = mallService.getBillsByShop(shop.getId());
            double revenue = bills.stream().mapToDouble(b -> b.getTotalAmount() != null ? b.getTotalAmount() : 0).sum();
            model.addAttribute("bills", bills);
            model.addAttribute("shopRevenue", revenue);
            model.addAttribute("myShop", shop);
        }
        return "owner/owner_reports";
    }

    @GetMapping("/staff")
    public String staff(Model model, HttpSession session) {
        if (!isOwner(session)) return "redirect:/auth/login.jsp";
        String ownerId = getOwnerUsername(session);
        List<Shop> myShops = mallService.getShopsByOwner(ownerId);
        if (!myShops.isEmpty()) {
            Shop shop = myShops.get(0);
            model.addAttribute("myShop", shop);
            model.addAttribute("employees", mallService.getEmployeesByShop(shop.getId()));
        }
        return "owner/manage_staff";
    }

    @PostMapping("/staff/add")
    public String addStaff(@RequestParam Long shopId, @RequestParam String name,
                           @RequestParam String designation, @RequestParam Double salary,
                           HttpSession session) {
        if (!isOwner(session)) return "redirect:/auth/login.jsp";
        Employee employee = new Employee();
        employee.setName(name);
        employee.setDesignation(designation);
        employee.setSalary(salary);
        mallService.getShopById(shopId).ifPresent(employee::setShop);
        mallService.saveEmployee(employee);
        return "redirect:/owner/staff?success=Employee+added";
    }

    @PostMapping("/staff/delete/{id}")
    public String deleteStaff(@PathVariable Long id, HttpSession session) {
        if (!isOwner(session)) return "redirect:/auth/login.jsp";
        mallService.deleteEmployee(id);
        return "redirect:/owner/staff?success=Employee+removed";
    }

    @Autowired private com.example.demo.repository.NotificationRepository notificationRepo;

    @GetMapping("/notifications")
    public String notifications(Model model, HttpSession session) {
        if (!isOwner(session)) return "redirect:/auth/login.jsp";
        String ownerId = getOwnerUsername(session);
        List<Shop> myShops = mallService.getShopsByOwner(ownerId);
        if (!myShops.isEmpty()) {
            model.addAttribute("myShop", myShops.get(0));
        }
        model.addAttribute("notifications", notificationRepo.findAllOrderByIdDesc());
        return "owner/notifications";
    }

    @Autowired private com.example.demo.repository.GlobalMessageRepository globalMessageRepository;

    @GetMapping("/messenger")
    public String messenger(Model model, HttpSession session) {
        if (!isOwner(session)) return "redirect:/auth/login.jsp";
        model.addAttribute("username", session.getAttribute("username"));
        model.addAttribute("messages", globalMessageRepository.findAll());
        return "owner/messenger";
    }

    @Autowired private com.example.demo.repository.ComplaintRepository complaintRepo;

    @GetMapping("/complaints")
    public String complaints(Model model, HttpSession session) {
        if (!isOwner(session)) return "redirect:/auth/login.jsp";
        String ownerId = getOwnerUsername(session);
        List<Shop> myShops = mallService.getShopsByOwner(ownerId);
        if (!myShops.isEmpty()) {
            Shop shop = myShops.get(0);
            model.addAttribute("myShop", shop);
            model.addAttribute("complaints", complaintRepo.findByShopIdOrderByTimestampDesc(shop.getId()));
        }
        return "owner/complaints";
    }
}
