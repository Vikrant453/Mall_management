package com.example.demo.repository;

import com.example.demo.entity.GlobalMessage;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GlobalMessageRepository extends JpaRepository<GlobalMessage, Long> {
}
