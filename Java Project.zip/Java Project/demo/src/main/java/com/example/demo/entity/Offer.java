package com.example.demo.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "shop_offers")
public class Offer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "offer_id")
    private Long id;

    @Column(name = "offer_text", length = 500, nullable = false)
    private String offerText;
    @Column(name = "discount_percent")
    private Integer discountPercent;

    @OneToOne
    @JoinColumn(name = "shop_id", unique = true)
    private Shop shop;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getOfferText() { return offerText; }
    public void setOfferText(String offerText) { this.offerText = offerText; }
    public Integer getDiscountPercent() { return discountPercent; }
    public void setDiscountPercent(Integer discountPercent) { this.discountPercent = discountPercent; }
    public Shop getShop() { return shop; }
    public void setShop(Shop shop) { this.shop = shop; }
}
