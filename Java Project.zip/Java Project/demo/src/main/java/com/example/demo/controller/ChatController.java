package com.example.demo.controller;

import com.example.demo.entity.GlobalMessage;
import com.example.demo.entity.Notification;
import com.example.demo.model.ChatMessage;
import com.example.demo.repository.GlobalMessageRepository;
import com.example.demo.repository.NotificationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Controller;

import java.text.SimpleDateFormat;
import java.util.Date;

@Controller
public class ChatController {

    @Autowired
    private NotificationRepository notificationRepository;

    @Autowired
    private GlobalMessageRepository globalMessageRepository;

    @MessageMapping("/chat.sendMessage")
    @SendTo("/topic/public")
    public ChatMessage sendMessage(@Payload ChatMessage chatMessage) {
        String time = new SimpleDateFormat("HH:mm").format(new Date());
        chatMessage.setTimestamp(time);
        
        // Save to Database for both admin and owner
        GlobalMessage gm = new GlobalMessage();
        gm.setSender(chatMessage.getSender());
        gm.setContent(chatMessage.getContent());
        gm.setRole(chatMessage.getRole());
        gm.setTimestamp(time);
        globalMessageRepository.save(gm);

        // Also save as Notification if admin broadcasts (optional legacy support)
        if ("admin".equals(chatMessage.getRole())) {
            Notification notif = new Notification();
            notif.setContent(chatMessage.getContent());
            notif.setTimestamp(time);
            notificationRepository.save(notif);
        }
        
        return chatMessage;
    }
}
