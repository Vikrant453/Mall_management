package com.example.demo.socket;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Component
public class AnnouncementServer {

    private ServerSocket serverSocket;
    private final List<PrintWriter> clientWriters = new ArrayList<>();
    private final ExecutorService threadPool = Executors.newCachedThreadPool();
    private volatile boolean running = true;

    @PostConstruct
    public void startServer() {
        threadPool.execute(() -> {
            try {
                serverSocket = new ServerSocket(9090);
                System.out.println("Announcement Socket Server started on port 9090");

                while (running) {
                    Socket clientSocket = serverSocket.accept();
                    System.out.println("New client connected: " + clientSocket.getInetAddress());
                    
                    PrintWriter writer = new PrintWriter(clientSocket.getOutputStream(), true);
                    synchronized (clientWriters) {
                        clientWriters.add(writer);
                    }
                    
                    writer.println("Welcome to ParkSmart Real-time Announcements!");
                }
            } catch (IOException e) {
                if (running) {
                    e.printStackTrace();
                }
            }
        });
    }

    public void broadcastAnnouncement(String message) {
        synchronized (clientWriters) {
            for (PrintWriter writer : clientWriters) {
                writer.println("ANNOUNCEMENT: " + message);
            }
        }
    }

    @PreDestroy
    public void stopServer() {
        running = false;
        try {
            if (serverSocket != null) {
                serverSocket.close();
            }
            threadPool.shutdown();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
